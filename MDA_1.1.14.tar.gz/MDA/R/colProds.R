colProds <- function(x,...) { if (sum(x<0)>0) { stop('colProds does not work if there negative elements in x') } else { return(exp(colSums(log(x),...))) } }
