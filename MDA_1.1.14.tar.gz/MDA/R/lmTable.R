pairwise.contrasts <- function(n) {
  idx <- combn(n,2)
  ans <- matrix(0,nrow=n,ncol=ncol(idx))
  for (i in 1:ncol(ans)) {
    ans[i,idx[1,i]] <- (-1)
    ans[i,idx[2,i]] <- 1
  }
  ans 
}

getValsCont <- function(y,xcont,varName,adj) {
  stopifnot(is.numeric(y) & is.numeric(xcont))
  if (!missing(adj)) stopifnot(is.data.frame(adj))
  #
  xcont <- (xcont-mean(xcont)) / sd(xcont)
  if (missing(adj)) {
    model <- lm(y ~ xcont)
  } else {
    text <- paste('y ~ ',paste(paste('adj$',colnames(adj),sep=''),collapse=' + '),'+ xcont')
    model <- lm(eval(parse(text=text)))
  }
  se <- summary(model)$coefficients['xcont','Std. Error']
  fc <- coef(model)['xcont']
  ci <- c(fc -1.96*se,fc +1.96*se)
  pval <- anova(model)['xcont','Pr(>F)']
  ans <- data.frame(FoldChange=fc,CI.low=ci[1],CI.up=ci[2],Pvalue=pval)
  rownames(ans) <- paste(varName,'(+1SD)')
  return(ans)
}

getValsCate <- function(y,xcate,varName,adj) {
  stopifnot(is.numeric(y) & is.factor(xcate))
  if (!missing(adj)) stopifnot(is.data.frame(adj))
  #
  idx <- combn(levels(xcate),2)  
  if (missing(adj)) {
    text <- 'y ~ xcate'
  } else {
    text <- paste('y ~ ',paste(paste('adj$',colnames(adj),sep=''),collapse=' + '),'+ xcate')
  }
  n.levels <- length(levels(xcate))
  if (n.levels==2) {
    model <- lm(eval(parse(text=text)))
    tmp <- summary.lm(model)$coefficients
    tmp <- tmp[grepl('xcate',rownames(tmp)),]
    ans <- data.frame(tmp['Estimate'],tmp['Estimate']-1.96*tmp['Std. Error'],tmp['Estimate']+1.96*tmp['Std. Error'],tmp['Pr(>|t|)'])
    rownames(ans) <- paste(varName,': ',levels(xcate)[2],' vs ',levels(xcate)[1],sep='')
  } else {
    cm.xcate <- pairwise.contrasts(n.levels)
    rownames(cm.xcate) <- paste('Comp',1:n.levels,sep='')
    ans <- do.call(rbind,lapply(as.list(1:nrow(cm.xcate)),function(i) {
      model <- aov(eval(parse(text=text)), contrasts=list(xcate=make.contrasts(cm.xcate[i,,drop=F])))
      tmp <- summary.lm(model)$coefficients[paste('xcateComp',i,sep=''),]
      ans <- c(tmp['Estimate'],tmp['Estimate']-1.96*tmp['Std. Error'],tmp['Estimate']+1.96*tmp['Std. Error'],tmp['Pr(>|t|)'])
      ans
    }))
    rownames(ans) <- paste(varName,': ',apply(combn(levels(xcate),2),2,function(x) paste(x[2],x[1],sep=' vs ')),sep='')
    ans <- rbind(c(NA,NA,NA,anova(lm(eval(parse(text=text))))[1,'Pr(>F)']),ans)
    rownames(ans)[1] <- varName
  }
  colnames(ans) <- c('FoldChange','CI.low','CI.up','Pvalue')
  return(ans)
}

lmUnivTable <- function(y,x) {
  #Report a table with univariate lm results for all columns in x
  #Note: p-value computed using F-test
  stopifnot(is.data.frame(x))
  for (i in 1:ncol(x)) { if (is.character(x[,i])) x[,i] <- factor(x[,i]) }
  sel <- rowSums(is.na(x))==0; y <- y[sel]; x <- x[sel,,drop=FALSE] #remove NAs
  isfac <- sapply(x,is.factor) 
  ans <- matrix(NA,nrow=1,ncol=4)
  colnames(ans) <- c('FoldChange','CI.low','CI.up','Pvalue')
  for (i in 1:ncol(x)) {
    if (!isfac[i]) {
      ans <- rbind(ans,getValsCont(y,x[,i],colnames(x)[i]))
    } else {
      ans <- rbind(ans,getValsCate(y,x[,i],colnames(x)[i]))
    }
  }
  ans <- ans[-1,]
  ans[,1:3] <- exp(ans[,1:3])
  ans
}

lmMultivTable <- function(y,x) {
  #Report a table with multivariate lm results for all columns in x
  #Note: p-value computed using F-test
  stopifnot(is.data.frame(x))
  for (i in 1:ncol(x)) { if (is.character(x[,i])) x[,i] <- factor(x[,i]) }
  sel <- rowSums(is.na(x))==0; y <- y[sel]; x <- x[sel,,drop=FALSE] #remove NAs
  isfac <- sapply(x,is.factor) 
  ans <- matrix(NA,nrow=1,ncol=4)
  colnames(ans) <- c('FoldChange','CI.low','CI.up','Pvalue')
  for (i in 1:ncol(x)) {
    if (!isfac[i]) {
      ans <- rbind(ans,getValsCont(y,x[,i],colnames(x)[i],adj=x[,-i,drop=F]))
    } else {
      ans <- rbind(ans,getValsCate(y,x[,i],colnames(x)[i],adj=x[,-i,drop=F]))
    }
  }
  ans <- ans[-1,]
  ans[,1:3] <- exp(ans[,1:3])
  ans
}
