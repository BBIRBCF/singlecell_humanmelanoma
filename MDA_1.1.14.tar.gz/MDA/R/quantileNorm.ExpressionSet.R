quantileNorm.ExpressionSet <- function(x) { exprs(x) <- quantileNorm(exprs(x)); return(x) }
