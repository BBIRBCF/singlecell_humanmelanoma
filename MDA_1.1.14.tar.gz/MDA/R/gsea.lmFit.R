gsea.lmFit <- function(x,design,contrasts,keepDesignMeans,BROAD='',geneinfo,orderby,decreasing=TRUE,parametric=TRUE,fdr=.05,savexls=TRUE,outputdir,prefix='') {
#GSEA via linear models. Considers GO, KEGG and BROAD enrichment
# - x: ExpressionSet
# - design: design matrix as required by lmFit
# - contrasts: contrast matrix as required by contrasts.fit 
# - keepDesignMeans: name of the columns in design for which coefficients should be saved (e.g. to compute group means)
# - geneinfo: data.frame with additional information to be saved for each gene. Must have rownames with accession numbers
# - BROAD: categories of BROAD genesets to be tested for enrichment. Any string containing i tests for category ci, i.e. specify 1:5 for all categories c1-c5, c(2,3,5) for c2, c3 and c5 etc.
# - parametric: should parametric p-values be computed?; fdr= cutoff for BY adjusted p-values
# - fdr: detailed gene annotation is only obtained for sets with adjusted P-value < fdr
# - savexls, outputdir: if TRUE text file with extension xls is save to outputdir (outputdir defaults to the working directory)
# - prefix: characters to be added at the beginning of each xls file. Ignored if savexls==FALSE.
require("Biobase")
require("Category")
require("GSEABase")
require("annotate")
require("genefilter")
require("KEGG.db")
require("GO.db")
require("limma")
gseaanno <- paste("require('GeneSet",annotation(x),"')",sep='',collapse='')
eval(parse(text=gseaanno))

gseasumt <- function(gsc,gsctype,x,design,contrasts,keepDesignMeans,parametric) {
  #GSEA summing tstat from individual genes
  require(AnnotationDbi)
  Am <- incidence(gsc) #incidence matrix
  genesel <- colnames(Am) %in% featureNames(x); Am <- Am[,genesel] #remove genes in gsc not present in x
  nsF <- x[colnames(Am),]  #select genes in x present in the GeneSetCollection

  lm1 <- lmFit(nsF,design); lm2 <- contrasts.fit(lm1,contrasts=contrasts); eb <- eBayes(lm2)
  rttStat <- eb$t
  m <- coef(lm1)[,keepDesignMeans]
  rsA <- rowSums(Am); rs2 <- rsA[rsA>=10] #number of genes per geneset
  Am2 <- Am[rsA>=10,] #select genesets with >10 genes

  tA <- Am2 %*% rttStat  #geneset-level test stat
  tAadj <- tA/sqrt(rs2)
  mA <- (Am2 %*% m)/rs2
  names(tA) <- names(tAadj) <- rownames(Am2)
  if (!is.null(colnames(contrasts))) colnames(tA) <- colnames(tAadj) <- colnames(contrasts)
  
  if (parametric) {
    pvals <- pnorm(-abs(tAadj))
  } else {
    pvals <- pnorm(-abs(tAadj))
    cat('Non-parametric p-values not currently implemented. Computing parametric p-values instead.\n')
  }
  padj <- p.adjust(pvals,method='BY')
  if (is.matrix(padj) & ncol(padj)==1) colnames(padj) <- 'pvalBY'
  namesChange <- rownames(Am2)
  if (length(namesChange)==0) {
    cat('No BROAD sets with more than 10 genes could be mapped\n')
    tabout <- 'No BROAD sets with more than 10 genes could be mapped'
  } else {
    if (gsctype=='KEGG') {
      set <- as.vector(unlist(getPathNames(namesChange)))
      tabout <- data.frame(namesChange,set=set,round(mA,2),tstat=round(tAadj,4),pvalBY=padj)
    } else if (gsctype=='GO') {
      set <- AnnotationDbi::mget(namesChange, envir = GOTERM)
      set <- unlist(lapply(set,function(z) return(Term(z))))
      tabout <- data.frame(namesChange,set=set,round(mA,2),tstat=round(tAadj,4),pvalBY=padj)
    } else if (gsctype=='BROAD') {
      tabout <- data.frame(namesChange,round(mA,2),tstat=round(tAadj,4),pvalBY=padj)
    }
    tabout <- tabout[order(padj[,1]),]
  }
return(list(tabout=tabout,nsF=nsF))
}


taboutanno <- function(tabout,gsctype,x,geneinfo,fdr,gsc) {
#Obtain gene annotation for gene sets with adjusted p-value <= fdr
  require(AnnotationDbi)
  if ('pvalBY' %in% colnames(tabout)) setsel <- tabout$pvalBY<=fdr else setsel <- rep(TRUE,nrow(tabout))
  if (gsctype=='KEGG') { #probe IDs associated with each set
    envPATH2PROBE <- AnnotationDbi::get(paste(annotation(x),"PATH2PROBE", sep = ""))
    probe <- AnnotationDbi::mget(as.character(tabout[setsel,1]),envPATH2PROBE)
  } else if (gsctype=='GO') {
    envGO2PROBE <- AnnotationDbi::get(paste(annotation(x),"GO2PROBE", sep = ""))
    probe <- AnnotationDbi::mget(as.character(tabout[setsel,1]),envGO2PROBE)
  } else if (gsctype=='BROAD') {
    probe <- lapply(gsc[rownames(tabout[setsel,])],function(z) return(z@geneIds))
    names(probe) <- names(gsc[rownames(tabout[setsel,])])
  }
  probe <- lapply(probe,function(z) return(z[z %in% featureNames(x)]))
  setid <- rep(names(probe),unlist(lapply(probe,function(z) return(length(z)))))
  probe <- as.character(unlist(probe))
  envSYMBOL <- AnnotationDbi::get(paste(annotation(x),"SYMBOL", sep = "")); symbol <- unlist(AnnotationDbi::mget(probe,envSYMBOL)) #gene symbol
  envGENENAME <- AnnotationDbi::get(paste(annotation(x),"GENENAME", sep = "")); gname <- unlist(AnnotationDbi::mget(probe,envGENENAME)) #gene name
  envENTREZID <- AnnotationDbi::get(paste(annotation(x),"ENTREZID", sep = "")); entrezid <- unlist(AnnotationDbi::mget(probe,envENTREZID)) #entrez ID
  if (missing(geneinfo)) {
    genelist <- data.frame(setid,probe,entrezid,symbol,gname)
  } else { genelist <- data.frame(setid,probe,entrezid,symbol,gname,geneinfo[probe,]) }
  return(genelist)
}


if (!is.character(BROAD)) BROAD <- paste(as.character(BROAD),collapse='')
if (!missing(outputdir)) setwd(outputdir)

cat('Selecting genes with Entrez ID and removing duplicates... ')
x <- nsFilter(x,require.entrez=TRUE,remove.dupEntrez=TRUE,var.func=IQR,var.filter=FALSE)$eset
cat('Done.\n')

# KEGG
tabout <- list()
cat('KEGG:    Loading GeneSetCollection... ')
e <- paste("data(",annotation(x),"GSCKEGG)",sep=''); eval(parse(text=e))
e <- paste(annotation(x),"GSCKEGG <- ",annotation(x),"GSCKEGG[sapply(",annotation(x),"GSCKEGG,function(z) return(length(z@geneIds)))>=10]",sep=''); eval(parse(text=e))  #select sets with >=10 genes
cat('Obtaining test statistics... ')
e <- paste("tabout$KEGG <- gseasumt(gsc=",annotation(x),"GSCKEGG,gsctype='KEGG',x=x,design=design,contrasts=contrasts,keepDesignMeans=keepDesignMeans,parametric=parametric)$tabout",sep=''); eval(parse(text=e))
cat('Annotating genes... ')
tabout$KEGGgenelist <- taboutanno(tabout=tabout$KEGG,gsctype='KEGG',x=x,geneinfo=geneinfo,fdr=fdr)
if (!missing(orderby)) {
  seqsetid <- cumsum(c(TRUE,tabout$KEGGgenelist$setid[-1]!=tabout$KEGGgenelist$setid[-nrow(tabout$KEGGgenelist)]))
  seqsetid <- seqsetid[order(tabout$KEGGgenelist[,orderby],decreasing=decreasing)]
  tabout$KEGGgenelist <- tabout$KEGGgenelist[order(tabout$KEGGgenelist[,orderby],decreasing=decreasing),]
  tabout$KEGGgenelist <- tabout$KEGGgenelist[order(seqsetid),]
}
cat('Done.\n')

# GO
cat('GO:      Loading GeneSetCollection... ')
e <- paste("data(",annotation(x),"GSCGO)",sep=''); eval(parse(text=e))
e <- paste(annotation(x),"GSCGO <- ",annotation(x),"GSCGO[sapply(",annotation(x),"GSCGO,function(z) return(length(z@geneIds)))>=10]",sep=''); eval(parse(text=e))  #select sets with >=10 genes
cat('Obtaining test statistics... ')
e <- paste("tabout$GO <- gseasumt(gsc=",annotation(x),"GSCGO,gsctype='GO',x=x,design=design,contrasts=contrasts,keepDesignMeans=keepDesignMeans,parametric=parametric)$tabout",sep=''); eval(parse(text=e))
cat('Annotating genes... ')
tabout$GOgenelist <- taboutanno(tabout=tabout$GO,gsctype='GO',x=x,geneinfo=geneinfo,fdr=fdr)
if (!missing(orderby)) {
  seqsetid <- cumsum(c(TRUE,tabout$GOgenelist$setid[-1]!=tabout$GOgenelist$setid[-nrow(tabout$GOgenelist)]))
  seqsetid <- seqsetid[order(tabout$GOgenelist[,orderby],decreasing=decreasing)]
  tabout$GOgenelist <- tabout$GOgenelist[order(tabout$GOgenelist[,orderby],decreasing=decreasing),]
  tabout$GOgenelist <- tabout$GOgenelist[order(seqsetid),]
}
cat('Done.\n')

# BROAD
if (BROAD!='') {
  for (i in 1:5) {
    if (length(grep(as.character(i),BROAD))>0) {
      cat('BROAD c',as.character(i),': Loading GeneSetCollection... ',sep='')
      fname <- paste(annotation(x),'GSCBROADc',as.character(i),sep='');
      eval(parse(text=paste('data(',fname,')',sep=''))); gsc <- eval(parse(text=fname))
      gsc <- gsc[sapply(gsc,function(z) return(length(z@geneIds)))>=10] #select sets with >=10 genes
      cat('Obtaining test statistics... ')
      ans <- gseasumt(gsc=gsc,gsctype='BROAD',x=x,design=design,contrasts=contrasts,keepDesignMeans=keepDesignMeans,parametric=parametric)
      e <- paste("tabout$BROADc",as.character(i)," <- ans$tabout",sep=''); eval(parse(text=e))
      cat('Annotating genes... ')
      e <- paste("tabout$BROADc",as.character(i),"genelist<- taboutanno(tabout=tabout$BROADc",as.character(i),",gsctype='BROAD',x=ans$nsF,geneinfo=geneinfo,fdr=fdr,gsc=gsc)",sep='')
      eval(parse(text=e))
      if (!missing(orderby)) {
        e <- paste("seqsetid <- cumsum(c(TRUE,tabout$BROADc",i,"genelist$setid[-1]!=tabout$BROADc",i,"genelist$setid[-nrow(tabout$BROADc",i,"genelist)]))",sep='')
        eval(parse(text=e))
        e <- paste("seqsetid <- seqsetid[order(tabout$BROADc",i,"genelist[,orderby],decreasing=decreasing)]",sep=''); eval(parse(text=e))
        e <- paste("tabout$BROADc",i,"genelist <- tabout$BROADc",i,"genelist[order(tabout$BROADc",i,"genelist[,orderby],decreasing=decreasing),]",sep=''); eval(parse(text=e))
        e <- paste("tabout$BROADc",i,"genelist <- tabout$BROADc",i,"genelist[order(seqsetid),]",sep=''); eval(parse(text=e))
      }
      cat('Done.\n')
    }
  }
  cat('Done.\n')
}


#save to xls
if (!is.null(tabout$KEGG) && savexls) {
  dirname <- paste(prefix,'GSEA_KEGG',sep='')
  dir.create(dirname,showWarnings=FALSE)
  write.table(tabout$KEGG,file.path(dirname,paste(dirname,'.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
  write.table(tabout$KEGGgenelist,file.path(dirname,paste(prefix,'GSEA_KEGGgenelist.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
}
if (!is.null(tabout$GO) && savexls) {
  dirname <- paste(prefix,'GSEA_GO',sep='')
  dir.create(dirname,showWarnings=FALSE)
  write.table(tabout$GO,file.path(dirname,paste(dirname,'.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
  write.table(tabout$GOgenelist,file.path(dirname,paste(prefix,'GSEA_GOgenelist.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
}
for (i in 1:5) {
  setlist <- eval(parse(text=paste('tabout$BROADc',as.character(i),sep='')))
  if (!is.null(setlist) && savexls) {
    if (!is.character(setlist)) {
      dirname <- paste(prefix,'GSEA_BROADc',as.character(i),sep='')
      dir.create(dirname,showWarnings=FALSE)
      write.table(setlist,file.path(dirname,paste(dirname,'.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
      genelist <- eval(parse(text=paste('tabout$BROADc',as.character(i),'genelist',sep='')))
      write.table(genelist,file.path(dirname,paste(prefix,'GSEA_BROADc',as.character(i),'genelist.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
    }
  }
}

return(tabout)
}
