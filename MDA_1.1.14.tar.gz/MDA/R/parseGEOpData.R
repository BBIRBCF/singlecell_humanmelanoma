parseGEOpData <- function(x, multCharCol=FALSE) {
  oldpdata <- pData(x)[,grep('characteristics',names(pData(x))),drop=FALSE]
  for (i in 1:ncol(oldpdata)) { oldpdata[,i] <- as.character(oldpdata[,i]) }
  allvnames <- unlist(oldpdata)
  if (multCharCol) { allvnames <- unlist(strsplit(as.character(allvnames),";")) }
  allvnames <- strsplit(as.character(allvnames),":")
  allvnames <- unique(sapply(allvnames,function(x) x[1]))
  allvnames <- allvnames[!is.na(allvnames)]
  allvnames <- sub("^ ","",allvnames)
  pdata <- data.frame(matrix(NA,nrow=nrow(oldpdata),ncol=length(allvnames))); names(pdata) <- allvnames
  rownames(pdata) <- rownames(oldpdata)
  for(i in 1:nrow(oldpdata)) {
    if (multCharCol) { z <- unlist(strsplit(as.character(oldpdata[i,]),";")) } else { z <- as.character(oldpdata[i,]) }
    z <- strsplit(z,":")
    vnames <- sapply(z,function(x) x[1])  #variable names
    vnames <- sub("^ ","",vnames)
    vals <- sapply(z,function(x) x[2])  #values
    vals <- sub("^ ","",vals)
    sel <- ((!is.na(vnames)) & (!is.na(vals)))  #remove NAs
    vnames <- vnames[sel]
    vals <- vals[sel]
    #pdata[i,vnames] <- vals
    vals <- tapply(vals,INDEX=vnames,FUN=paste,collapse=';')
    pdata[i,names(vals)] <- vals
  }
  options(warn=-1)
  for (i in 1:ncol(pdata)) {
    numna <- sum(is.na(pdata[,i]))
    pdatanum <- as.numeric(pdata[,i])
    numconv <- sum(is.na(pdatanum))
    if (numconv==numna) { pdata[,i] <- pdatanum } else { pdata[,i] <- factor(pdata[,i]) }
  }
  options(warn=0)  
  pdata <- new("AnnotatedDataFrame",pdata)
  if (!is.null(x[['title']])) pdata$title <- x[['title']]
  if (!is.null(x[['geo_accession']])) pdata$geo_accession <- x[['geo_accession']]
  xanno <- annotation(x)
  x <- new("ExpressionSet",exprs=exprs(x), phenoData=pdata, featureData=featureData(x))
  annotation(x) <- xanno
  x[['title']]
  return(x)
}
