setGeneric("GeneSetMeans", function(x, genesets, center=FALSE, scale=FALSE, summary='mean') standardGeneric("GeneSetMeans"))

#Gene ID conversion
setGeneric("entreztomouse4302", function(entrezid, mouse4302, homol, useSymbols=FALSE) standardGeneric("entreztomouse4302"))
setGeneric("hgu133plus2tohgu133a", function(hgu133plus2, hgu133a, simplify=TRUE) standardGeneric("hgu133plus2tohgu133a"))
setGeneric("hgu133plus2tomouse4302", function(hgu133plus2, mouse4302, homol, returnTable=FALSE) standardGeneric("hgu133plus2tomouse4302"))
setGeneric("hgu133plus2todrosophila2", function(hgu133plus2, drosophila2, homol, returnTable=FALSE) standardGeneric("hgu133plus2todrosophila2"))
setGeneric("entrezidtosymbol", function(entrezid, symbol, organism, homol, returnTable=FALSE) standardGeneric("entrezidtosymbol"))

setGeneric("selHighIQR", function(x,by) standardGeneric("selHighIQR"))
