limmal2e <- function(x,group,grouplev,wl2e=TRUE,fdrseq=c(.01,.05,.1),fdrfile,file,dir,gene.info,caption='Number of DE genes for several FDR cut-offs') {
#Limma analysis for 2 groups, followed by eBayes and wl2e. Saves results to file.xls and file.tex.
# INPUT
# - x: expression data
# - group: vector indicating to which group each column of x belongs to
# - grouplev: character vector indicating the labels of the two groups to be compared. No need to specify if group only has two levels.
# - wl2e: if set to TRUE a WL2E with a t component is used to find posterior probabilities of DE
# - fdrseq: sequence of FDR cut-offs. If 'file' specified, function will count nb of DE genes for each cutoff and save in a latex table.
# - fdrfile: fdr cutoff to be used for the output xls file. A column with -1,0,1 is added to indicate significant differences.
# - file: name of the output xls file
# - gene.info: gene information to be added to the output xls file
# RETURNS
# - tstat: moderated t-test statistic
# - pval: unadjusted p-values
# - pde: post prob of DE
# - rej: result of comparison and
# - w0: WL2E estimated proportion of EE genes
require(xtable)
require(limma)
group <- factor(group)
if (missing(grouplev)) {
  grouplev <- levels(group)
  if (length(grouplev)!=2) stop("groups must have exactly 2 levels. Specify grouplev to select a subset of levels.")
}
if (missing(fdrfile)) fdrfile <- fdrseq[1]
colsel <- group==grouplev[1] | group==grouplev[2]
group <- factor(group[colsel])
design <- model.matrix(~ -1+group)
colnames(design) <- levels(group)
contrast <- matrix(c(1,-1),ncol=1)
lm1 <- lmFit(x[,colsel],design)
lm2 <- contrasts.fit(lm1,contrast)
eb <- eBayes(lm2)  #moderated t-statistics
nuest <- eb$df.prior+eb$df.residual[1] #fixed-component WL2E
if (wl2e) l2e <- ebayes.l2e(as.vector(eb$t),wl2e=TRUE,nufix=nuest,fdr=fdrfile) else { l2e <- list(w0.wl2e=NA,rej.wl2e=NA,w0.wl2e=NA) }
if (!missing(file)) {
  if (!missing(dir)) setwd(dir)
  fc <- eb.fold(eb,alpha=.05,base='2')
  xout <- data.frame(lm1$coefficients,fold.change=fc[,1],fold.ci=ci2txt(fc[,-1]),prob.de=l2e$wl2e.pde,rej=l2e$rej.wl2e)
  names(xout)[1:2] <- levels(group)
  if (!missing(gene.info)) xout <- data.frame(gene.info,xout)
  xout <- xout[order(xout$prob.de,decreasing=TRUE),]
  write.table(xout,paste(file,'.xls',sep=''),row.names=FALSE,col.names=TRUE,sep='\t',dec=',')
  if (wl2e) {  #write LaTeX tables with number of rejected genes
    nrej <- matrix(NA,nrow=length(fdrseq),ncol=3)
    for (i in 1:length(fdrseq)) {
      rej <- sign(eb$t)*(l2e$wl2e.pde>find.threshold(l2e$wl2e.pde,fdr=fdrseq[i])$threshold)
      nrej[i,] <- table(factor(rej,levels=-1:1))
    }
    nrej <- cbind(fdrseq,nrej)
    colnames(nrej) <- c('FDR',paste(paste(levels(group)[1],c('<','=','>')),levels(group)[2]))
    xlab <- paste('tab:',file,sep='')
    xtab <- xtable(nrej,caption=caption,label=xlab,digits=c(0,2,rep(0,3)))
    print(xtab,file=paste(file,'.tex',sep=''),include.rownames=FALSE)
  }
}
return(list(tstat=eb$t,pval=eb$p.value,pde=l2e$wl2e.pde,rej=l2e$rej.wl2e,w0=l2e$w0.wl2e))
}
