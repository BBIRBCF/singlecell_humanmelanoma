norm2gene <- function(x,method='rma',toKeep=0) {
  require(AnnotationDbi)
  require(genefilter)
  require(annotation(x),character.only=TRUE)
  if (annotation(x)=="pd.mogene.1.0.st.v1") {
    library(mogene10sttranscriptcluster.db)
    library(mogene10stprobeset.db)
  } else if (annotation(x)=="pd.hugene.1.0.st.v1") {
    library(hugene10sttranscriptcluster.db)
    library(hugene10stprobeset.db)
  } else {
    stop('annotation(x) has to be one off pd.mogene.1.0.st.v1 or pd.hugene.1.0.st.v1')
  }
  
  if(class(x)!='ExpressionSet') stop('x has to be of class ExpressionSet.')
  
  #get probeset-cluster correspondence
  if (annotation(x)=="pd.mogene.1.0.st.v1") {
    tclus <- toTable(mogene10sttranscriptclusterENTREZID); colnames(tclus)[1] <- 'trans'
    prset <- toTable(mogene10stprobesetENTREZID); colnames(prset)[1] <- 'prset'
  } else if (annotation(x)=="pd.hugene.1.0.st.v1") {
    tclus <- toTable(hugene10sttranscriptclusterENTREZID); colnames(tclus)[1] <- 'trans'
    prset <- toTable(hugene10stprobesetENTREZID); colnames(prset)[1] <- 'prset'
  }
  trans <- merge(tclus,prset,by='gene_id')
  trans <- trans[,c('trans','prset')]
  trans <- trans[match(featureNames(x),trans$prset),'trans']
  
  myRma <- function(x) {
    if (class(x)=='numeric') x <- t(matrix(x)) else x <- as.matrix(x)
    ans <- medpolish(x,trace.iter=FALSE)
    return(ans$overall + ans$col)
  }

  myInterQ <- function(x) {
    if (class(x)=='numeric') x <- t(matrix(x)) else x <- as.matrix(x)
    interq <- rowQ(imat=x,ceiling(3*ncol(x)/4))-rowQ(imat=x,ceiling(ncol(x)/4))
    if (toKeep==0) {
      x <- x[interq==max(interq),]
      if (class(x)!='numeric') x <- x[1,,drop=FALSE] #there are two rows with maximal interq distance
    } else {
      numSel <- ceiling(nrow(x)*toKeep)
      highInterq <- interq[order(interq)][(length(interq)-numSel+1):length(interq)]
      x <- x[interq %in% highInterq,,drop=FALSE]
    }
    return(x)
  }

  if (method=='interQ') {
    exprsx <- by(exprs(x),trans,myInterQ)
    exprsx <- do.call('rbind',exprsx)
    ans <- new("ExpressionSet",exprs=exprsx,phenoData=phenoData(x),annotation=annotation(x))
  } else if (method=='rma') {
    exprsx <- by(exprs(x),trans,myRma)
    exprsx <- do.call('rbind',exprsx)
    ans <- new("ExpressionSet",exprs=exprsx,phenoData=phenoData(x),annotation=annotation(x))
    if (annotation(ans)=='pd.hugene.1.0.st.v1') annotation(ans) <- 'hugene10sttranscriptcluster' else if (annotation(ans)=='pd.mogene.1.0.st.v1') annotation(ans) <- 'mogene10sttranscriptcluster'
    if (ncol(ans)>2) {
      ans <- nsFilter(ans,require.entrez=FALSE,remove.dupEntrez=TRUE,var.func=IQR,var.filter=FALSE)$eset
    } else {
      warning('transcriptClusters could not be summarized to genes due to having only two samples.')
    }
  }

  return(ans)
}
