getQueryLink <- function (ids, repository = "ug") {
#Redefines getQueryLink function from 'annotate' to add localfile repository
    switch(tolower(repository), ug = return(annotate:::getQuery4UG(ids)), 
        ll = return(annotate:::getQuery4LL(ids)), affy = return(annotate:::getQuery4Affy(ids)), 
        gb = return(annotate:::getQuery4GB(ids)), sp = return(annotate:::getQuery4SP(ids)), 
        omim = return(annotate:::getQuery4OMIM(ids)), fb = return(annotate:::getQuery4FB(ids)), 
        en = return(annotate:::getQuery4EN(ids)), tr = return(annotate:::getQuery4TR(ids)), 
        go = return(annotate:::getQuery4GO(ids)),
        phenoplot = return(getQuery4PHENOPLOT(ids)), #line added           
        localfile = return(getQuery4LOCALFILE(ids)), #line added
        mirbase = return(getQuery4miRBase(ids)), #line added
        broad = return(getQuery4BROAD(ids)), #line added
        kegg = return(getQuery4KEGG(ids)), #line added
        miranda = return(getQuery4MIRANDA(ids)), #line added                      
        stop("Unknown repository name"))
}
