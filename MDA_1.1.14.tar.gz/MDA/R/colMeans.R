colMeans <- function (x, ...) { if (is.vector(x)) { x } else { base::colMeans(x, ...) } }
