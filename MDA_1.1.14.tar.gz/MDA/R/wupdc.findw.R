wupdc.findw <- function(x, nu, weight=TRUE, f0='t') {
## Find weight for Weighted Univariate Partial Density Component Estimation

## Purpose:  fit model   w N(0,1) or w t_nu, where t_nu is Student's t distribution with nu degrees
##           of freedom. 

## Inputs:
##          x - n x d input data matrix (d=1 vector OK)
##         nu - degrees of freedom (only used if f0=='t')
##     weight - if set to TRUE, minimization is weighted according to N(0,1) or t_nu
##         f0 - f0=='t' uses t component; f0=='normal' uses normal component
## Output:
##          list containing estimated  (m=mean sig=sig w=w min=min)

    if (!is.vector(x)) stop("x must be a vector")
    if (f0=='t') { if (missing(nu)) stop('t-Student fit requires the degrees of freedom nu') }
    if ((f0!='normal') & (f0!='t')) stop('not valid value was specified for f0')
    mu <- 0; sig <- 1
    
    if (f0=='normal') {
      if (weight==FALSE) {
        a <- 1/(2*sqrt(pi*sig)); b <- 2*mean(dnorm(x,mu,sqrt(sig)))
      } else {
        m <- 3*mu/sig; v <- 3/sig
        a <- exp(-1.5*mu^2/sig + .5*m^2/v)/(2*pi*sig^(3/2)*sqrt(v))
        b <- 2*mean(dnorm(x,mu,sqrt(sig))^2)
      }
      w <- b/(2*a)
    } else {
      if (weight==FALSE) {
        k <- exp(lgamma(nu/2)-lgamma((nu+1)/2)+lgamma(nu+1)-lgamma(nu+1/2))
        w <- k * mean((1+(x-mu)^2/(sig*nu))^(-(nu+1)/2))
      } else {
        k <- exp(lgamma(nu/2)-lgamma((nu+1)/2)+lgamma((3*nu+3)/2)-lgamma((3*nu+2)/2))
        w <- k * mean((1+(x-mu)^2/(sig*nu))^(-nu-1))
      }
    }
    }
