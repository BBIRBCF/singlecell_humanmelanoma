colCV <- function(x,...) { return(colSD(x,...)/colMeans(x,...)) }
