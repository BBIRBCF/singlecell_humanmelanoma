eb.fold <- function(eb.fit,alpha=.05,base='2') {
#Computes fold change and CI from a list returned by eBayes
#Note: when fold change < 1, -1/fold change is reported
inv <- eb.fit$coef<0
se.coef <- abs(qt(alpha/2,df=eb.fit$df.residual+eb.fit$df.prior))*eb.fit$coef/eb.fit$t
if (base=='e') {
  fold <- exp(eb.fit$coef)*(1-inv) - exp(-eb.fit$coef)*(inv)
  fold.cilow <- exp(eb.fit$coef-se.coef)*(1-inv) - exp(-eb.fit$coef-se.coef)*(inv)
  fold.ciup <- exp(eb.fit$coef+se.coef)*(1-inv) - exp(-eb.fit$coef+se.coef)*(inv)
} else if (base=='2') {
  fold <- 2^eb.fit$coef*(1-inv) - 2^(-eb.fit$coef)*(inv)
  fold.cilow <- 2^(eb.fit$coef-se.coef)*(1-inv) - 2^(-eb.fit$coef-se.coef)*(inv)
  fold.ciup <- 2^(eb.fit$coef+se.coef)*(1-inv) - 2^(-eb.fit$coef+se.coef)*(inv)
} else { stop('argument base must take the value 2 or e') }
if (ncol(eb.fit$coef)>1) {  #order columns when there are several contrasts
  colseq <- integer(0)
  for (i in 1:ncol(eb.fit$coef)) { colseq <- c(colseq, ncol(eb.fit$coef)*(0:2) + i) }
} else { colseq <- 1:3 }
ans <- cbind(fold,fold.cilow,fold.ciup)[,colseq]
return(ans)
}
