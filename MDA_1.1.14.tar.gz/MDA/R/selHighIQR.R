getSel <- function(x,by) {
  stopifnot(class(x)=='matrix')
  stopifnot(class(by)=='character')  
  iqr <- apply(x,1,function(x) quantile(x,.75)-quantile(x,.25))
  tmp <- data.frame(symbol=by,iqr,rownum=1:length(iqr))
  tmp <- sqldf('select symbol, min(iqr), rownum from tmp group by symbol')
  ans <- tmp$rownum
  return(ans)
}

setMethod("selHighIQR", signature(x='matrix', by='character'), 
function(x, by) {
  sel <- getSel(x,by)
  ans <- x[sel,]
  return(ans)
}
)

setMethod("selHighIQR", signature(x='ExpressionSet', by='character'), 
function(x, by) {
  sel <- getSel(exprs(x),by)
  ans <- x[sel,]
  featureNames(ans) <- by[sel]
  return(ans)
}
)

