quantileNorm.data.frame <- function(x) { return(quantileNorm.matrix(x)) }
