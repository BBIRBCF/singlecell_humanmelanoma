zscoreAdjustment <- function(x,adjustmentVariable,center=TRUE,scale=TRUE) {
  if (missing(adjustmentVariable)) stop('adjustmenVariable must be specified')
  UseMethod("zscoreAdjustment")
}
