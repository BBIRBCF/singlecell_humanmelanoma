find.threshold <- function(pde,fdr) {
# Input
#   pde: vector of probabilities of differential expression
#   fdr: desired FDR
# Output:
#   threshold: threshold for probability of differential expression with estimated FDR closest to 'fdr'
#   fdrest: estimated FDR

pde <- pde[order(pde)]
imin <- 1; imax <- length(pde); i <- round(imax/2)
fdrest <- find.fdr(pde,pde[i])$fdr
while ((imax-imin>1) & (abs(fdr-fdrest)>.001)) {
  if (fdrest>fdr) { imin <- i } else { imax <- i }
  i <- round(.5*(imin+imax))
  fdrest <- find.fdr(pde,pde[i])$fdr
}
return(list(threshold=pde[i],fdrest=fdrest))

}
