anovaAdjustment <- function(x,adjustmentVariable,na.rm=FALSE) {
  #Perform ANOVA adjustment, i.e. remove effect of nuisance covariates via lmFit. This can be used to remove experimentation date or batch processing effects on gene expression.
  # - x: ExpressionSet with expression values to be adjusted
  # - adjustmentVariable: name of adjustment variable, which must be contained in pData(x).
  # Output: ExpressionSet with adjusted expression values
  if (missing(adjustmentVariable)) stop('adjustmenVariable must be specified')
  UseMethod("anovaAdjustment")

  require(limma)
  require(Biobase)
}
