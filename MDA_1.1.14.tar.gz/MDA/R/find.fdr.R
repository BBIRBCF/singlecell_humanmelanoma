find.fdr <- function(v,threshold) {
# Input
#   v: vector with posterior probabilities of differential expression (missing values are removed)
#   k: vector with thresholds to declare differential expression (defaults to a sequence between min(v),max(v))
# Output: a list containing the following elements
#   threshold: the k vector
#   fdr: estimated FDR
#   fnr: estimated FNR

if (missing(v)) stop('The vector of posterior probabilities v must be specified')
if (sum(is.na(v))>0) v <- v[!is.na(v)]
if (missing(threshold)) threshold <- seq(min(v),max(v)-diff(range(v))/100,diff(range(v))/100)

fdr <- fnr <- rep(NA,length(threshold))
for (i in 1:length(threshold)) {
  fdr[i] <- sum((v>=threshold[i])*(1-v))/sum(v>=threshold[i])
  fnr[i] <- sum((v<threshold[i])*v)/sum(v<threshold[i])
}

return(list(threshold=threshold,fdr=fdr,fnr=fnr))
}
