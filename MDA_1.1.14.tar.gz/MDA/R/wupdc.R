wupdc <- function(x, mu0, sig0, mu, sig, w, wmax=1) {
## Weighted Univariate Partial Density Component Estimation (wupdc)

## Purpose:  fit model   w N(mu,sig) weighted according to N(mu0,sig0)

## Inputs:
##          x - n x d input data matrix (d=1 vector OK)
##        mu0 - mean of the weighting normal pdf
##       sig0 - var of the weighting normal pdf
##         mu - input guess for mean (default is mu0)
##        sig - input guess for variance (default is sig0)
##          w - input guess for weight (default w=.9*wmax)
##       wmax - upper bound for w (default wmax=1)
## Output:
##          list containing estimated  (m=mean sig=sig w=w min=min)

    if (!is.vector(x)) stop("x must be a vector")

    if (missing(mu0)) { mu0 <- mean(x) }
    if (missing(sig0)) { sig0 <- var(x) }
    if (sig0<0) stop('sig0 must be positive')
    if (missing(mu)) mu <- mu0
    if(missing(sig)) {
        sig <- sig0
    } else {
        if (sig<=0) stop("sig must be positive!")
    } 

    if (missing(w)) {
        w <- 0.9*wmax
    } else {
        if (w <= 0 | w>=wmax) stop("w must be between 0 and wmax")
    }

    logit <- function(x) { log((x+.1)/(1-x+.1)) }
    
    pdc <- function(th) {
      mu <- th[1]
      sig <- exp(th[2])
      w <- wmax/(1+exp(-th[3]))

      t1 <- exp((mu0*sig+2*mu*sig0)^2 /(2*sig0*sig*(sig+2*sig0)) -mu^2/sig-.5*mu0^2/sig0)/(2*pi*sqrt(sig)*sqrt(sig+2*sig0))
      t2 <- mean(dnorm(x,mu0,sqrt(sig0))*dnorm(x,mu,sqrt(sig)))

      w^2 * t1 - 2 * w * t2
    }
    
    x0 <- c(mu, log(sig), log((w/wmax)/(1-w/wmax)))
    ans <- nlm(pdc, x0, print.level=0, iterlim=100)
    m.ans <- ans$estimate[1]
    sig.ans <- exp(ans$estimate[2])
    w.ans <- wmax/(1+exp(-ans$estimate[3]))
    
    list(m=m.ans, sig=sig.ans, w=w.ans, min=ans$minimum, wmax=wmax)
}
