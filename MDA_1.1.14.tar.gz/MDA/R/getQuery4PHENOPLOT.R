getQuery4PHENOPLOT <- function (ids) {
#Get directory for LOCAL FILE
    blanks <- ids == "&nbsp;"
    path <- paste("phenoPlots",ids,sep=.Platform$file.sep)
    out <- paste(path,".pdf",sep = "")
    out <- sub(":","",out) #remove strange characters from file name
    out[blanks] <- "&nbsp;"
    return(out)
}
