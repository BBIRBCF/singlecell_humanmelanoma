rowProds <- function(x,...) { if (sum(x<0)>0) { stop('rowProds does not work if there negative elements in x') } else { return(exp(rowSums(log(x),...))) } }
