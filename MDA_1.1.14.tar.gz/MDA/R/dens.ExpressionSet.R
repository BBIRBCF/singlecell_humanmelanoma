dens.ExpressionSet <- function(x,main='',ylab='Density',...) {
  dens.matrix(exprs(x),main=main,ylab=ylab,...)
}
