MAnorm <- function(x,y,method='gam',gam.link='inverse',smoother.span=0.4,scale=TRUE,extended=FALSE) {
  if (class(x)!='numeric' | class(y)!='numeric') stop ('x and y have to be of class numeric!')
  if (sum(x<0)>0 | sum(y<0)>0) stop ('Neither x nor y can have negative values!')
  m <- log2(x) - log2(y)
  a <- log2(x) + log2(y)
  if (method=='lowess') {
    stop('approxfun (which is needed for lowess method) showed to have bugs under R 2.10.0 and 2.10.1. If you have some other version please remove this line of code and test if everything goes fine.')
    fit <- lowess(x=a,y=m,f=smoother.span)
    averageM <- approxfun(x=fit$x,y=fit$y)
    m.centered <- m-averageM(a)
    plot(a,m,pch='.',main='Before MA normalization'); lines(a[order(a)],averageM(a)[order(a)],col=4)
  } else if (method=='loess') {
    fit <- loess(m ~ a,span=smoother.span)
    m.centered <- m-predict(fit,a)
    plot(a,m,pch='.',main="Before MA normalization"); lines(a[order(a)],predict(fit,a)[order(a)],col=4)
  } else if (method=='gam') {
    require(mgcv)
    fit <- gam(m ~ s(a), family=gaussian(link='identity'))
    m.pred <- predict(fit,data.frame(a))
    m.centered <- as.numeric(m-m.pred)
    plot(a,m,pch='.',main="Before MA normalization"); lines(a[order(a)],m.pred[order(a)],col=4)
  } else {
    stop('method has to be gam, lowess or loess!!')
  }
  ans <- m.centered
  plot(a,m.centered,pch='.',ylab='m',main='After centering'); abline(h=0,lty=2,col=2)
  if (scale) {
    if (method=='lowess') {
      fit <- lowess(x=a,y=m.centered^2,f=smoother.span)
      averageM <- approxfun(x=fit$x,y=fit$y)
      m2 <- averageM(a)
      if (sum(m2<=0)>0) warning('Some variances where estimated to be negative! You should better use gam method.')
      m2[m2<0.01] <- 0.01
      m.scaled <- m.centered / sqrt(m2)
    } else if (method=='loess') {
      fit <- loess(m.centered^2 ~ a,span=smoother.span)
      m2 <- predict(fit,a)
      if (sum(m2<=0)>0) warning('Some variances where estimated to be negative! You should better use gam method.')
      m2[m2<0.01] <- 0.01
      m.scaled <- m.centered / sqrt(m2)
      if (extended) {
	plot(density(predict(fit,a)),main='Predicted variance density before scaling')
	plot(a,predict(fit,a),ylab='predicted variance',main='Predicted variance before scaling')
	plot(a,m.centered^2,pch='.',ylab='m^2',main='Before scaling (variance in red)'); lines(a[order(a)],predict(fit,a)[order(a)],col=2)
	fit <- loess(m.scaled^2 ~ a,span=smoother.span)      
	plot(density(predict(fit,a)),main='Predicted variance density after scaling')
	plot(a,predict(fit,a),ylab='predicted variance',main='Predicted variance after scaling')
	plot(a,m.scaled^2,pch='.',ylab='m^2',main='After scaling (variance in red)'); lines(a[order(a)],predict(fit,a)[order(a)],col=2)
      }
    } else if (method=='gam') {
      if (gam.link=='inverse') {
        fit <- gam(m.centered^2 ~ s(a), family=Gamma(link='inverse'))
        m.pred <- 1/as.numeric(predict(fit,data.frame(a)))
      } else if (gam.link=='log') {
        fit <- gam(m.centered^2 ~ s(a), family=Gamma(link='log'))
        m.pred <- exp(as.numeric(predict(fit,data.frame(a))))
      } else {
        stop("gam.link has to be 'inverse' or 'log'!")
      }
      m.scaled <- m.centered / sqrt(m.pred)
      if (extended) {
        plot(density(m.pred),main='Predicted variance density before scaling')
        plot(a,m.pred,ylab='predicted variance',main='Predicted variance before scaling')
        plot(a,m.centered^2,pch='.',ylab='m^2',main='Before scaling (variance in red)'); lines(a[order(a)],m.pred[order(a)],col=2)
        if (gam.link=='inverse') {
          fit <- gam(m.scaled^2 ~ s(a), family=Gamma(link='inverse')); m.pred2 <- 1/predict(fit,data.frame(a))
        } else if (gam.link=='log') {
          fit <- gam(m.scaled^2 ~ s(a), family=Gamma(link='log')); m.pred2 <- exp(predict(fit,data.frame(a)))
        }
        plot(density(m.pred2),main='Predicted variance density after scaling')
        plot(a,m.pred2,ylab='predicted variance',main='Predicted variance after scaling')
        plot(a,m.scaled^2,pch='.',ylab='m^2',main='After scaling (variance in red)'); lines(a[order(a)],m.pred2[order(a)],col=2)
      }
    }
    plot(a,m.scaled,pch='.',ylab='m',main='After scaling'); abline(h=0,lty=2,col=2)
    ans <- m.scaled
  }
  return(ans)
}
