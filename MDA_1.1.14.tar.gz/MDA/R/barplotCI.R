barplotCI <- function(x,groups,alpha=.05,exp=FALSE,base='nat',refgroup,reference=ifelse(exp,'divide','subtract'),plot=TRUE,plot.ci=TRUE,ci.l=NA,ci.u=NA,order,...) {
  require(gplots)
  if (!is.factor(groups)) {
    warning('groups have been converted to factor')
    groups <- factor(groups)
  }
  if (length(unique(groups))==1) {
    lm1 <- lm(x ~ 1)
    b <- c(coef(lm1),confint(lm1,level=1-alpha))
    names(b) <- as.character(groups)[1]
    if (exp & base=='nat') { b <- exp(b) } else if (exp & base!='nat') { b <- as.numeric(base)^b }
    barplot2(b[1],names=names(b)[1],plot.ci=TRUE,ci.l=b[2],ci.u=b[3],...)
  } else {
    lm1 <- lm(x ~ -1 + groups)
    b <- cbind(coef(lm1),confint(lm1,level=1-alpha))
    rownames(b) <- sub('groups','',rownames(b))
    if (exp) {
      if (base=='nat') { b <- exp(b) } else if (base=='logit') { b <- 1/(1+exp(-b)) } else { b <- as.numeric(base)^b }
    }
    if (!missing(refgroup)) {
      if (reference=='divide') b <- b/b[refgroup,1] else if (reference=='subtract') b <-  b-b[refgroup,1]
    }
    if (!missing(order)) { b <- b[order,] }
    if (plot) {
      barplot2(b[,1],names=rownames(b),plot.ci=TRUE,ci.l=b[,2],ci.u=b[,3],...)
    } else {
      return(b)
    }
  }
}
