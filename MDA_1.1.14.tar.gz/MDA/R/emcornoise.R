emcornoise <- function(x,S0,not.noise,equalmeans=TRUE,toleps=1e-10,itlim=1000,trace=TRUE,ridgel=1e-10) {
  # EM algorithm to fit a mixture of 2 multivariate normals: pi0*N(mu0,S0) + (1-pi0)*N(mu1,S1), where S0 is diagonal and S1 is non-diagonal
  # Input
  # - x: matrix or data frame with gene expression values. Samples (conditions) are in rows, genes are in columns.
  # - S0: diagonal matrix giving S0. If missing it is estimated from the data.
  # - not.noise: vector with indexes of rows in x that are known to come from the N(mu1,S1) component.
  # - equalmeans: equalmeans==TRUE forces mu0==mu1, i.e. both components have the same mean
  # - eps: tolerance to determine convergence. Algorithm stops when the change in parameter estimates is < eps in square norm.
  # - itlim: iteration limit. Algorithm stops after itlim iterations even if convergence criterion specified by eps is not met.
  # - trace: if trace==TRUE iteration progress is displayed.
  # - ridgel: small constant to add to the diagonal elements of covar matrices, to avoid singularity
  # Output
  # - mu0, S0, mu1, S1, pi0: parameter estimates
  # - probnoise: probability that each row in x arises from N(mu0,S0) (i.e. that it contributes noise to the correlation estimation)
  
  require(mvtnorm)
  logit <- function(x) { return(log(x/(1-x))) }  #define useful function to determine convergence
  if (missing(not.noise)) not.noise <- double()

  #Initial estimates
  mu0 <- mu1 <- colMeans(x)
  S1 <- cov(x);
  if (missing(S0)) { S0unknown <- TRUE; S0 <- diag(diag(S1)) } else { S0unknown <- FALSE; S0 <- diag(diag(S0)) }
  if (det(S1)<1.0e-10) {
    warning('Covariance matrix is computationally singular. This usually happens when the correlation is 1. Skipped EM algorithm')
  } else {
    pi0 <- .5
    if (trace) cat("Iter mu0            S0             mu1            S1                   pi0\n")
    i <- 1; eps <- 2*toleps
    while (eps>toleps & i<itlim) {
      v <- pi0/(pi0+(1-pi0)*dmvnorm(x,mu1,S1)/dmvnorm(x,mu0,S0)) #prob that each sample comes from uncorrelated component
      v[not.noise] <- 0
      sv <- sum(v)
      pi0new <- mean(v) #new pi0 estimate
      if (equalmeans) { mu0new <- mu1new <- mu0 } else { mu0new <- colSums(v*x)/sv; mu1new <- colSums((1-v)*x)/(nrow(x)-sv) }
      if (S0unknown) {
        S0new <- diag(ridgel + colSums(v*t(t(x) - mu0new)^2)/sv) #new S0 estimate
      } else {
        S0new <- S0
      }
      S1new <- sqrt(1-v)*t(t(x)-mu1new); S1new <- (t(S1new) %*% S1new)/(nrow(x)-sv); diag(S1new) <- diag(S1new)+ridgel #new S1 estimate
      eps <- sum((mu0-mu0new)^2) + sum((mu1-mu1new)^2) + sum((S0-S0new)^2) + sum((S1-S1new)^2) + sum((logit(pi0)-logit(pi0new))^2)
      mu0 <- mu0new; mu1 <- mu1new; S0 <- S0new; S1 <- S1new; pi0 <- pi0new
      if (trace) { cat(format(i,width=4,justify='right'),format(mu0,digits=3,nsmall=3),"  ",format(diag(S0),digits=3,nsmall=3),"  ",format(mu1,digits=3,nsmall=3),"  ",format(diag(S1),digits=3,nsmall=3),format(S1[1,2],digits=3,nsmall=3),"  ",format(round(pi0,3),width=4,nsmall=4),"\n") }   #plot iteration information
      i <- i+1
    }
  } 
  return(list(mu0=mu0,S0=S0,mu1=mu1,S1=S1,pi0=pi0,probnoise=v))
}
