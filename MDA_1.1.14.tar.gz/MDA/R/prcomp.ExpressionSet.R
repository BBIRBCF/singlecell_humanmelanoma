prcomp.ExpressionSet <- function(x,...) {
  return(prcomp(t(exprs(x))))
}
