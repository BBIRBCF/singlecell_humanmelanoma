anovaAdjustment.ExpressionSet <- function(x,adjustmentVariable,na.rm=FALSE) {
  require(limma)
  if (!(adjustmentVariable %in% names(pData(x)))) { stop('Specified variable not found in pData') }
  design <- model.matrix(~ -1 + as.factor(pData(x)[,adjustmentVariable]))
  lm1 <- lmFit(x,design)
  linpred <- coef(lm1) %*% t(design)
  exprs(x) <- exprs(x) - linpred + rowMeans(exprs(x),na.rm=na.rm)
  return(x)
}
