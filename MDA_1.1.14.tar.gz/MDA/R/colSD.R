colSD <- function(x,...) { return(sqrt(colVar(x,...))) }
