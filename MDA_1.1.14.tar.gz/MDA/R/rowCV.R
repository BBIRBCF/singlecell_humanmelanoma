rowCV <- function(x,...) { return(rowSD(x,...)/rowMeans(x,...)) }
