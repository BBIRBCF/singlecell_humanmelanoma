list2data.frame <- function(x) {
  stopifnot(class(x)=='list')
  maxLen <- max(unlist(lapply(x,length)))
  ans <- lapply(x,function(y) c(y,rep(NA,maxLen-length(y))))
  ans <- do.call(cbind,ans)
  ans
}
