quantileNorm.matrix <- function(x) {
  probsx <- seq(0,1,length=nrow(x))
  qx <- quantile(x,probs=probsx)
  f <- approxfun(probsx,qx)
  for (i in 1:ncol(x)) {
    probsy <- rank(x[,i])/(nrow(x)+1)
    x[,i] <- f(probsy)
  }
  return(x)
}
