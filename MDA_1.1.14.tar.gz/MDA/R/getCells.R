getCells <- function (ids, repository = "ug") {
#introduce exception 4 localfile repository  
    if (is.list(ids)) {
        out <- vector()
        temp <- lapply(ids, getQueryLink, repository = repository)
        for (i in seq(along = ids)) {
            if (temp[i] != "&nbsp;") 
                out[i] <- paste("<P><A HREF=\"", temp[[i]], "\">", 
                  ids[[i]], "</A></P>", sep = "", collapse = "")
            else out[i] <- temp[i]
        }
    }
    else {
        temp <- getQueryLink(ids, repository)
        blanks <- temp == "&nbsp;"
        #epl: introduced an exception 4 localfile repository
        if (repository=='localfile') {out <- paste(" <A HREF=\"", temp, "\">", 'View', "</A>", sep = "")}
          else {out <- paste(" <A HREF=\"", temp, "\">", ids, "</A>", sep = "")}
        out[blanks] <- "&nbsp;"
    }
    return(out)
}
