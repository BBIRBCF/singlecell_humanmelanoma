setGeneric('plotPca',function (x, dimensions='2D', main='', color, color.legend='topleft', symbol, symbol.legend='bottomright', sampleNames='', xlab, ylab, zlab, xlim, ylim, zlim, centered=TRUE, pos=1, srt=0,...) standardGeneric('plotPca'))

setMethod('plotPca',signature(x='ExpressionSet'),
  function (x, dimensions='2D', main='', color, color.legend='topleft', symbol, symbol.legend='bottomright', sampleNames='', xlab, ylab, zlab, xlim, ylim, zlim, centered=TRUE, pos=1, srt=0, ...) {
    addLegend <- function(color,symbol,color.legend,symbol.legend) {
      if (ifelse(missing(color),'#@!',color)==ifelse(missing(symbol),'!#@',symbol)) {
          legend(color.legend,levels(factor(pData(x)[,color])),col=1:length(unique(pData(x)[,color])),pch=1:length(unique(pData(x)[,color])))
      } else {
        if (!missing(color)) legend(color.legend,lty=1,levels(factor(pData(x)[,color])),col=1:length(unique(pData(x)[,color])))
        if (!missing(symbol)) legend(symbol.legend,levels(factor(pData(x)[,symbol])),pch=1:length(unique(pData(x)[,symbol])))
      }
    }

    #error control
    if (!missing(color)) if(!(color %in% colnames(pData(x)))) stop('color is not in colnames(pData(x))')
    if (!missing(symbol)) if(!(symbol %in% colnames(pData(x)))) stop('symbol is not in colnames(pData(x))')
    if (!(dimensions %in% c('2D','3D','interactive3D'))) stop('dimensions has to be 2 or 3')
    #
    if (!missing(color)) if(class(pData(x)[,color])=='factor') pData(x)[,color] <- factor(as.character(pData(x)[,color]))
    if (!missing(symbol)) if(class(pData(x)[,symbol])=='factor') pData(x)[,symbol] <- factor(as.character(pData(x)[,symbol]))
    #
    pcdat <- prcomp(x)
    myPerc <- round(pcdat$sdev/sum(pcdat$sdev)*100,1)
    if (missing(xlab)) xlab <- paste('PC1 (',myPerc[1],'%)',sep=''); if (missing(ylab)) ylab <- paste('PC2 (',myPerc[2],'%)',sep=''); if (missing(zlab)) zlab <- paste('PC3 (',myPerc[3],'%)',sep='')
    if (centered) {
      if (missing(xlim)) xlim <- 1.5*range(c(pcdat$x[,1],pcdat$x[,2],pcdat$x[,3])); if (missing(ylim)) ylim <- 1.5*range(c(pcdat$x[,1],pcdat$x[,2],pcdat$x[,3])); if (missing(zlim)) zlim <- 1.5*range(c(pcdat$x[,1],pcdat$x[,2],pcdat$x[,3]))
    } else {
      if (missing(xlim)) xlim <- 1.5*range(pcdat$x[,1]); if (missing(ylim)) ylim <- 1.25*range(pcdat$x[,2]); if (missing(zlim)) zlim <- 1.25*range(pcdat$x[,3])
    }
    if (missing(color) & !missing(symbol)) color <- symbol else if (!missing(color) & missing(symbol)) symbol <- color
    if (missing(color)) col <- 1 else {
      if (class(pData(x)[,color])=='factor') {
        col <- as.numeric(pData(x)[,color])
      } else {
        col <- as.numeric(as.factor(as.character(pData(x)[,color])))
      }
    }
    if (missing(symbol)) sym <- 3 else {
      if (class(pData(x)[,symbol])=='factor') {
        sym <- as.numeric(pData(x)[,symbol])
      } else {
        sym <- as.numeric(as.factor(pData(x)[,symbol]))
      }
    }
    if (dimensions=='2D') {
      plot(pcdat$x[,1],pcdat$x[,2],xlab=xlab,ylab=ylab,xlim=xlim,ylim=ylim,main=main,col=col,pch=sym,...)
      addLegend(color,symbol,color.legend,symbol.legend)
      if (sampleNames!='') text(pcdat$x[,1],pcdat$x[,2],as.character(pData(x)[,sampleNames]),pos=pos,cex=.8,srt=srt,col=col)
    } else if (dimensions=='3D') {
      require(scatterplot3d)
      myCube <- scatterplot3d(pcdat$x[,1],pcdat$x[,3],pcdat$x[,2],type='h',xlab=xlab,ylab=zlab,zlab=ylab,xlim=xlim,ylim=zlim,zlim=ylim,main=main,color=col,pch=sym)
      addLegend(color,symbol,color.legend,symbol.legend)
      if (sampleNames!='') text(myCube$xyz.convert(pcdat$x[,1],pcdat$x[,3],pcdat$x[,2]),labels=pData(x)[,sampleNames],pos=pos,cex=.8,srt=srt,col=col)
    } else if (dimensions=='interactive3D') {
      require(rgl)
      plot3d(pcdat$x[,1],pcdat$x[,3],pcdat$x[,2],type='s',xlab=xlab,ylab=zlab,zlab=ylab,main=main,col=col,radius=2)
      plot.new()
      legend('top',title='Color',levels(pData(x)[,color]),col=1:length(unique(col)),lty=1)
      legend('bottom',title='Size (from small to big)',paste(1:length(unique(sym)),levels(factor(pData(x)[,symbol]))))
      if (!missing(symbol)) cat('No symbols can be used on 3D interactive plots. Use colors instead.\n')
      cat('Use rgl.snapshot function to take a screenshot.\n')
      cat('Legend has been send to X11 window.\n')
    }
  }
)
