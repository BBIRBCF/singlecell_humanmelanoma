getGSM <- function(GSM,keepMeta='description') {
  #Download series of GSM samples and return them as ExpressionSet
  # - GSM: character vector with GSM identifiers
  # - keepMeta: annotation variable that should be stored. Usually 'description' stores all the relevant annotation
  #Note: all annotation stored in a single variable in phenoData. Use parseGEOpData with multCharCol=TRUE to further structure the annotations
  cat('Downloading files...\n')
  pdata <- character(length(GSM))
  tmp <- getGEO(GSM[1])
  anno <- tmp@header$platform_id
  pdata[1] <- paste(Meta(tmp)[[keepMeta]],collapse=';')
  tmp <- Table(tmp)
  exprsx <- matrix(NA,nrow=nrow(tmp),ncol=length(GSM))
  rownames(exprsx) <- as.character(tmp$ID_REF); colnames(exprsx) <- GSM
  exprsx[,1] <- as.numeric(tmp[,'VALUE'])
  cat('.')
  valid <- rep(TRUE,length(GSM))
  errmsg <- options("show.error.messages")
  options(show.error.messages= -1)
  if (length(GSM)>1) {
    for (i in 2:length(GSM)) {
      tmp <- try(getGEO(GSM[i]))
      if (class(tmp)!='try-error') {
        pdata[i] <- paste(Meta(tmp)[[keepMeta]],collapse=';')
        tmp <- Table(tmp)
        if (!all(as.character(tmp$ID_REF) %in% rownames(exprsx))) {
          warning(paste('Some IDs are different in',GSM[i],'. Data from this sample not included'))
        } else {
          exprsx[as.character(tmp$ID_REF),i] <- as.numeric(tmp[,'VALUE'])
        }
      } else {
        warning(paste("Sample",GSM[i],"could not be downloaded (getGEO returned an error)"))
        valid[i] <- FALSE
      }
    }
  }
  options(show.error.messages=errmsg)
  pdata <- data.frame(GSM=GSM,characteristics_ch1=pdata)
  rownames(pdata) <- GSM
  pdata <- new("AnnotatedDataFrame",pdata)
  ans <- new("ExpressionSet",exprs=exprsx,phenoData=pdata)
  annotation(ans) <- anno
  return(ans[,valid]) 
}
