dens <- function(x,main='',ylab='Density',...) { UseMethod("dens") }
