htmlpage <- function (genelist, filename, title, othernames, table.head, 
    table.center = TRUE, repository = list("en"), ...) {
    if (!is.list(repository)) 
        stop("The repository argument must be a list!", call. = FALSE)
    chklen <- function(x) {
        if (is.data.frame(x) || is.matrix(x)) 
            dim(x)[1]
        else length(x)
    }
    getRows <- function(x) {
        paste("<P>", x, "</P>", collapse = "", sep = "")
    }
    if (is.data.frame(genelist)) 
        len.vec <- chklen(genelist)
    else if (is.list(genelist)) 
        len.vec <- sapply(genelist, chklen)
    else stop("The 'genelist' should be either a data.frame or a list", 
        call. = FALSE)
    if (!missing(othernames)) {
        if (is.data.frame(othernames)) 
            len.vec <- c(len.vec, chklen(othernames))
        else if (is.list(othernames)) 
            len.vec <- c(len.vec, sapply(othernames, chklen))
        else stop("The 'othernames' should be either a data.frame or a list", 
            call. = FALSE)
    }
    if (any(len.vec != len.vec[1])) 
        stop(paste("Some items in either", genelist, "or", othernames, 
            "have mis-matched lengths.\nPlease check this", "discrepancy and re-run.\n"), 
            .call = FALSE)
    if (is.list(repository)) {
        out <- NULL
        for (i in seq(along = repository)) {
            out <- cbind(out, getCells(genelist[[i]], repository[[i]]))
        }
    }
    else out <- getCells(genelist, repository)
    if (!missing(othernames)) {
        if (is.data.frame(othernames)) 
            out <- data.frame(out, othernames)
        else if (is.list(othernames)) {
            others <- vector("list", length(othernames))
            for (i in seq(along = othernames)) {
                if (is.data.frame(othernames[[i]])) 
                  others[[i]] <- othernames[[i]]
                else if (is.list(othernames[[i]])) {
                  others[[i]] <- sapply(othernames[[i]], getRows)
                }
                else {
                  others[[i]] <- othernames[[i]]
                }
            }
            out <- data.frame(out, as.data.frame(others))
        }
    }
    colnames(out) <- table.head
    out <- xtable(out, caption = if (!missing(title)) 
        title, ...)
    print(out, type = "html", file = filename, caption.placement = "top", 
        include.rownames = FALSE, sanitize.text.function = function(x) x, 
        ...)
}
