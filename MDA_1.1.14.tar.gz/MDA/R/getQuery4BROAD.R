getQuery4BROAD <- function (ids) {
#Get URL for BROAD gene set
    blanks <- ids == "&nbsp;"
    out <- paste("http://www.broad.mit.edu/gsea/msigdb/geneset_page.jsp?geneSetName=", ids, sep = "")
    out[blanks] <- "&nbsp;"
    return(out)
}
