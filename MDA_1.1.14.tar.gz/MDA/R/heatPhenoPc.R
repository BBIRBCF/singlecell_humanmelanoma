heatPhenoPc <- function(pc, pheno, cexRow=0.6, cexCol=0.8, main='') {
  stopifnot(nrow(pc)==nrow(pheno))
  #compute likelihood ratio tests
  ans <- matrix(nrow=ncol(pheno), ncol=ncol(pc), dimnames=list(colnames(pheno), colnames(pc)))
  for (i in 1:ncol(pheno)) {
    for (j in 1:ncol(pc)) {
      ans[i, j] <- anova(lm(pc[, j] ~ pheno[, i]))[1, 5]
    }
  }
#
  #make plot
  breaks <- c(0, 0.001, 0.01, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5, 1)
  col <- c('red', 'darkred', 'pink', 'grey', rep('white', 5))
  heatmap.2(ans, col=col, breaks=breaks, scale='none', dendrogram='none', symbreaks=TRUE, trace='none',
            Colv=F, Rowv=F, key=F, lhei=c(0.08,0.55), lwid=c(0.08, 0.55),
            cexRow=cexRow, cexCol=cexCol, main=main)
  #
  return(ans)
}
