heatmapMatrix <- function(x, signif, col=greenred(5), threshold, plotValues=TRUE, ...) {
  require(gplots)
  if (!missing(threshold)) { x2plot <- t((abs(x)>threshold)*sign(x)) } else { x2plot <- t(x) }
  if ((!(-1 %in% x2plot)) & (1 %in% x2plot)) col <- col[ceiling(.5*length(col)):length(col)]
  if ((!(1 %in% x2plot)) & (-1 %in% x2plot)) col <- col[1:ceiling(.5*length(col))]
  image(x2plot,col=col,xaxt='n',yaxt='n',...)
  nr <- nrow(x); nc <- ncol(x)
  x0 <- par('usr')[1] + seq(.5/nc,1-.5/nc,1/nc)*diff(par('usr')[1:2])
  y0 <- par('usr')[3] + seq(.5/nr,1-.5/nr,1/nr)*diff(par('usr')[3:4])
  yx <- expand.grid(y0,x0)
  if (plotValues) {
    mytext <- round(as.vector(x),2)
    if (!missing(signif)) {
      if (any(dim(x)!=dim(signif))) stop('Dimensions of x and signif do not match')
      mytext <- paste(mytext,ifelse(as.vector(signif),'*',''),sep='')
    }
    text(yx[,2],yx[,1],mytext)
  }
  mtext(colnames(x),1,at=x0,line=1)
  mtext(rownames(x),2,at=y0,line=1)
}
