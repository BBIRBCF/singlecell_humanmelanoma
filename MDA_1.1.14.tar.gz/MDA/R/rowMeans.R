rowMeans <- function (x, ...) { if (is.vector(x)) { x } else { base::rowMeans(x, ...) } }
