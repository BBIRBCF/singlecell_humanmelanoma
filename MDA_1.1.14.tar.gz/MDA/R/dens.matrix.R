dens.matrix <- function(x,main='',ylab='Density',...) {
  plot(density(x[,1]),main=main,ylab=ylab,...); for (i in 2:ncol(x)) { lines(density(x[,i]),lty=i,col=i) }
}
