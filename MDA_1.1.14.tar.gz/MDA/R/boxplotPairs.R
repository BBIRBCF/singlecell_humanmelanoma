pval2txt <- function(pval) ifelse(pval<.0001,'P<0.0001',paste('P=',round(pval,4),sep=''))

pairwise.wilcox <- function(x, g, p.adjust.method='none', paired=FALSE, ...) {
  wtest <- pairwise.wilcox.test(x=x,g=g,p.adjust.method=p.adjust.method,paired=paired,...)$p.value
  sel <- lower.tri(wtest,diag=TRUE)
  ans <- wtest[sel]; names(ans) <- paste(colnames(wtest)[col(wtest)[sel]], 'vs', rownames(wtest)[row(wtest)[sel]], sep='')
  ans
}

boxplotPairs <- function(groups,z,cex.sub=.8,...) {
  if (!is.factor(groups)) groups <- factor(groups)
  pval.k <- kruskal.test(z ~ groups)$p.value
  pval <- pval2txt(pairwise.wilcox(z, groups))
  if (length(pval)<=5) {
    pval <- paste(paste(names(pval),pval),collapse='; ')
  } else {
    pval <- paste(names(pval),pval)
    m <- ceiling(length(pval)/2)
    pval <- paste(paste(pval[1:m],collapse='; '),'\n',paste(pval[-1:-m],collapse='; '))
  }
  if (length(levels(groups))<=2) {
    sub <- paste('Kruskal-Wallis test,',ifelse(pval.k<.0001,'P<0.0001',paste('P=',round(pval.k,4),sep='')))
  } else {
    sub <- paste('Kruskal-Wallis test,',ifelse(pval.k<.0001,'P<0.0001',paste('P=',round(pval.k,4))),' | ',pval,sep='')
  }
  boxplot(z ~ groups, sub=sub, cex.sub=cex.sub, ...)
}

## boxplotPairs <- function(groups,z,cex.sub=.8,...) {
##   if (!is.factor(groups)) groups <- factor(groups)
##   pval <- kruskal.test(z ~ groups)$p.value
##   main <- paste('Kruskal-Wallis test,',ifelse(pval<.0001,'P<0.0001',paste('P=',round(pval,4),sep='')))
##   pval <- pval2txt(pairwise.wilcox(z, groups))
##   if (length(pval)<=5) {
##     pval <- paste(paste(names(pval),pval),collapse='; ')
##   } else {
##     pval <- paste(names(pval),pval)
##     m <- ceiling(length(pval)/2)
##     pval <- paste(paste(pval[1:m],collapse='; '),'\n',paste(pval[-1:-m],collapse='; '))
##   }
##   boxplot(z ~ groups, main=main, sub=pval, cex.sub=cex.sub, ...)
## }
