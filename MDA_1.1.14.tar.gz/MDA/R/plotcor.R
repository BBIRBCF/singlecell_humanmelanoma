setGeneric("plotcor", function (x, y, method='pearson', lowess=TRUE, addRegLine=FALSE, xlab, ylab, col=1, pch=20, sub, diagonal=FALSE, alpha=.05, showPval=FALSE, cex.up=1, cex.diag=1, cex.down=1, ...) standardGeneric("plotcor"))

setMethod("plotcor", signature(x='numeric', y='numeric'),
          function (x, y, method='pearson', lowess=TRUE, addRegLine=FALSE, xlab, ylab, col=1, pch=20, sub, ...) {
            stopifnot(!missing(x))
            stopifnot(!missing(y))  
            stopifnot(method %in% c('pearson', 'spearman'))  
            myplot <- function(x, y, sub, xlab, ylab, pch, col, ...) plot(x, y, sub=sub, col=col, pch=pch, xlab=xlab, ylab=ylab, ...)
            stopifnot(is.numeric(x) & is.numeric(y))
            if (missing(sub)) {
              cor <- cor.test(x, y, method=method)
              sub <- paste(method, 'estimate=', round(cor$estimate, 3), ' |  pvalue=', formatC(cor$p.value))
            }
            if (missing(pch)) pch <- 20
            if (missing(xlab)) xlab <- toupper(deparse(substitute(x)))
            if (missing(ylab)) ylab <- toupper(deparse(substitute(y)))
            myplot(x, y, sub=sub, xlab, ylab, pch, col, ...)
            if (lowess) lines(lowess(x, y), col=2)
            if (addRegLine) abline(lm(y~x), col=3, lwd=3)
          })

setMethod("plotcor", signature(x='matrix', y='missing'),
          function (x, method='pearson', lowess=TRUE, addRegLine=FALSE, col=1, pch=20, diagonal=FALSE, alpha=0.05, showPval=FALSE, cex.up=1, cex.diag=1, cex.down=1) {
            stopifnot(class(x)=='matrix')
            plotwithlines <- function(x, y, col) {
              if (missing(col)) { d <- dnorm(x)*dnorm(y); col <- gray(d/max(d)) }
              points(x, y, col=col, cex=cex.up, pch=pch)
              if (diagonal) abline(0, 1, col=2)
              sel <- !is.na(x) & !is.na(y)
              if (lowess) lines(lowess(x, y), col=2)
              if (addRegLine) abline(lm(y~x), col=3, lwd=3)
            }
            panel.cor <- function(x, y, digits=2, prefix="", col)    {
              usr <- par("usr"); on.exit(par(usr))
              par(usr = c(0, 1, 0, 1))
              r <- cor.test(x, y, method=method, use='pairwise.complete.obs')
              txt <- format(c(r$estimate, 0.123456789), digits=digits)[1]
              if (showPval) {
                txt <- paste(txt, ' (pval=', round(r$p.value, 3), ')', sep='')
              } else {
                if (r$p.value<alpha) txt <- paste(txt, '*')
              }
              txt <- paste(prefix, txt, sep="")
              text(0.5, 0.5, txt, cex = cex.down)
            }
            colnames(x) <- toupper(colnames(x))
            pairs(x, panel=plotwithlines, lower.panel=panel.cor, col=col,
                  cex.labels=cex.diag)
          }
          )
