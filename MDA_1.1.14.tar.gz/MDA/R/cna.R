#
# CNA FUNCTIONS & METHODS
#

cnaFun <- function(features, chromosome, start, end, scores, minProbes=40, organism='human') {
  require(sqldf)
  require(CGHbase)
  require(CGHcall)
  #handle error
  stopifnot(class(features)=='character')
  stopifnot(class(start)=='numeric')
  stopifnot(class(end)=='numeric')    
  stopifnot(class(scores)=='matrix')
  stopifnot(all(features==rownames(scores)))
  if (all(scores<=(-1) | scores>=1)) stop('There are no values of score between -1 and 1. Data is probably not in log scale!\n')
  stopifnot(minProbes>0)
  #if only one fc is provided CGHcall fails. Therefore we use the following workaround:
  if (ncol(scores)==1) {
    nScores <- 1
    scores <- data.frame(scores,dummy=scores[,1])
  } else {
    nScores <- ncol(scores)
  }
  #preprocess
  dat <- data.frame(BAC.clone=features,CHROMOSOME=chromosome,START_POS=start,END_POS=end,scores[,,drop=F])
  sel <- apply(dat,1,function(x) !any(is.na(x)))
  dat <- dat[sel,]
  dat <- dat[order(dat$CHROMOSOME),]
  dat$CHROMOSOME <- as.numeric(dat$CHROMOSOME)
  sel.chr <- which(table(dat$CHROMOSOME) > minProbes)
  dat <- dat[dat$CHROMOSOME %in% sel.chr,]
  dat <- dat[order(dat$CHROMOSOME,dat$START_POS,dat$END_POS),]
  #summarize probes with same position
  repeats <- sqldf("select count(BAC_clone) repeats from dat group by CHROMOSOME, START_POS")$repeats #CGHcall only uses st postion
  if (any(repeats>1)) {
    oldnames <- colnames(scores)
    colnames(dat)[-1:-4] <- letters[1:ncol(scores)]
    txt4fc <- paste(paste('avg(', letters[1:ncol(scores)],')', sep=''), collapse=', ')
    dat <- sqldf(paste("select min(BAC_clone), CHROMOSOME, START_POS, END_POS,", txt4fc,"from dat group by CHROMOSOME, START_POS"))
    colnames(dat)[c(1,5:ncol(dat))] <- c('BAC.clone',oldnames)
    warnings('Some probesets have the same position on chromosome. Their fold changes have been averaged.\n')
  }
  #cghcall
  cghdata <- cghRaw(dat)
  numchr <- sum(sel.chr)
  cghdata <- CGHcall::preprocess(cghdata, maxmiss=30, nchrom=numchr,nclass=3)
  #segmentation
  seg.cghdata <- segmentData(cghdata,method='DNAcopy')
  postseg.cghdata <- postsegnormalize(seg.cghdata)
  #determine regions with gains and losses
  result <- CGHcall(postseg.cghdata, organism=organism)
  result.exp <- ExpandCGHcall(result,postseg.cghdata)
  #if only one fc was provided remove the dummy one we added to avoid error in CGHcall
  if (nScores==1) result.exp <- result.exp[,1]
  #add chr name to fData (this will be used in the plot method)
  chrName <- levels(chromosome)[fData(result.exp)$Chromosome]
  fData(result.exp) <- data.frame(fData(result.exp),chrName=chrName)
  return(result.exp)
}

setGeneric("cna",function (eset, features, chromosome, start, end, scores, minProbes=40, organism='human') standardGeneric("cna"))

setMethod("cna",signature(eset='missing', features="character", chromosome='factor', start='numeric', end='numeric', scores="matrix"),
  function (features, chromosome, start, end, scores, minProbes=40, organism='human') {
    cnaFun(features, chromosome, start, end, scores, minProbes, organism)
  }
)

setMethod("cna",signature(eset="ExpressionSet", features="missing", chromosome='missing', start='missing', end='missing', scores="matrix"),
  function (eset, scores, minProbes=40, organism='human') {
  #get anno
  eval(parse(text=paste('library(',annotation(eset),'.db)',sep='')))
  chr <- eval(parse(text=paste(annotation(eset),'CHR',sep='')))
  chrloc <- eval(parse(text=paste(annotation(eset),'CHRLOC',sep='')))
  chrlocend <- eval(parse(text=paste(annotation(eset),'CHRLOCEND',sep='')))
  #preprocess
  features <- featureNames(eset)
  chromosome <- factor(unlist(lapply(AnnotationDbi::mget(featureNames(eset),chr,ifnotfound=NA),function(x) x[1])))
  tmp1 <- unlist(lapply(AnnotationDbi::mget(featureNames(eset),chrloc,ifnotfound=NA),function(x) mean(x,na.rm=T)))
  tmp2 <- unlist(lapply(AnnotationDbi::mget(featureNames(eset),chrlocend,ifnotfound=NA),function(x) mean(x,na.rm=T)))
  tmp1[is.nan(tmp1)] <- NA
  tmp2[is.nan(tmp2)] <- NA
  tmp <- data.frame(tmp1,tmp2)
  start <- apply(abs(tmp),1,min)
  end <- apply(abs(tmp),1,max)
  #call fun
  cna(features=features, chromosome=chromosome, start=start, end=end, scores=scores, minProbes=minProbes, organism=organism)
  }
)

#
# PLOT FUNCTIONS & METHODS
#

plotCnaChr <- function(cnacall,sel.chr,sel.sam,ylim.abs=2,chrLab='',ylab='log2 ratio',hideLabs=FALSE) {
  require(graphics)
  sameAsPrev <- function(x) {
    x.p <- x[-1]
    x <- x[-length(x)]
    ans <- c(FALSE,x==x.p)
    ans
  }
  plot.es <- function(cnacall,sel.chr,sel.sam,chrLab,ylim.abs=5) {
    x <- rowMeans(fData(cnacall[sel.chr,])[,c('Start','End')])
    y <- copynumber(cnacall[sel.chr,sel.sam])
    main <- ifelse(hideLabs,'',paste('Chromosome',chrLab))
    plot(x,y,pch=20,ylim=c(-ylim.abs,ylim.abs),cex=0.3,main=main,xlab=ifelse(hideLabs,'','Position'),ylab=ylab,axes=F,col=densCols(x,y))
    if (!hideLabs) {
      box(); axis(1); axis(2)
    }
    abline(h=0)
  }
  add.segment <- function(cnacall,sel.chr,sel.sam) {
    x <- rowMeans(fData(cnacall[sel.chr,])[,c('Start','End')])  
    y <- as.numeric(segmented(cnacall[sel.chr,sel.sam]))
    y <- y[order(x)]
    x <- sort(x)
    idx <- c(which(!sameAsPrev(y)),length(y)+1)
    for (i in 1:c(length(idx)-1)) {
      graphics::segments(x[idx[i]],y[idx[i]],x[idx[i+1]-1],y[idx[i+1]-1],col=4,lwd=5)
    }
  }
  add.pde <- function(cnacall,sel.chr,sel.sam,ylim.abs=5) {
    x <- rowMeans(fData(cnacall[sel.chr,])[,c('Start','End')])
    y.g <- probgain(cnacall[sel.chr,sel.sam])
    y.g <- y.g[order(x)]
    y.g <- (1-y.g)*2*ylim.abs-ylim.abs
    y.l <- probloss(cnacall[sel.chr,sel.sam])
    y.l <- y.l[order(x)]
    y.l <- y.l*2*ylim.abs-ylim.abs
    x <- (sort(x))
    st.g <- which(!sameAsPrev(y.g))
    en.g <- c((st.g-1)[-1],length(y.g))
    st.l <- which(!sameAsPrev(y.l))
    en.l <- c((st.l-1)[-1],length(y.l))
    col.g <- paste(rgb(42/255,165/255,42/255),'90',sep='')
    col.l <- paste(rgb(165/255,42/255,42/255),'90',sep='')
    rect(x[st.g],ylim.abs,x[en.g],y.g[en.g],col=col.g,lwd=0,border=NA)
    rect(x[st.l],-ylim.abs,x[en.l],y.l[en.l],col=col.l,lwd=0,border=NA)
    y.pos <- seq(-ylim.abs,ylim.abs,length.out=11)
    y.lab <- as.character(seq(0,1,length.out=11))
    text(rep(min(x),10),y.pos,sort(y.lab,T),pos=2,col=col.g,cex=0.5)
    text(rep(max(x),10),y.pos,y.lab,pos=4,col=col.l,cex=0.5)  
    rect(min(x),-ylim.abs,max(x),ylim.abs,border='grey')  
  }
  sel.chr <- chromosomes(cnacall) %in% sel.chr
  plot.es(cnacall,sel.chr,sel.sam,chrLab,ylim.abs=ylim.abs)
  add.segment(cnacall,sel.chr,sel.sam)
  add.pde(cnacall,sel.chr,sel.sam,ylim.abs=ylim.abs)
}

plotCna <- function(cnacall,sel.sam,ylim.abs=2,chrLabels='',main='') {
  #change pos
  chr <- fData(cnacall)$Chromosome
  pos <- rowMeans(fData(cnacall)[,c('Start','End')])
  tmp <- data.frame(chr,pos)
  max.pos <- cumsum(unlist(by(tmp,tmp$chr,function(x) max(x$pos))))
  for (i in 2:length(unique(chr))) fData(cnacall)[chr==unique(chr)[i],c('Start','End')] <- fData(cnacall)[chr==unique(chr)[i],c('Start','End')] + max.pos[i-1]
  fData(cnacall)[,'Chromosome'] <- rep(1,nrow(cnacall))
  plotCnaChr(cnacall,sel.chr=1,sel.sam=sel.sam,hideLabs=T)
  abline(v=max.pos[-length(max.pos)],lwd=1,col=1)
  box(); axis(2)
  tmp <- c(0,max.pos)
  at <- sapply(2:length(tmp),function(i) mean(c(tmp[i],tmp[i-1])))
  axis(1,at=at,labels=chrLabels,cex.axis=0.3)
  title(main=main,sub='Chromosomes')
}

setMethod("plot", signature(x="cghCall"), #this overrides the method in CGHbase
function (x, selChr='both')
{
  #reorder
  o <- order(fData(x)$Chromosome, rowMeans(fData(x)[,c('Start','End')]))
  x <- x[o,]
  #plot
  for (i in 1:ncol(x)) {
    sample <- sampleNames(x)[i]
    chr <- unique(chromosomes(x))
    if (is.factor(fData(x)$chrName)) {
      chrname <- unique(as.character(fData(x)$chrName))
    } else if (is.character(fData(x)$chrName)) {
      chrname <- unique(fData(x)$chrName)
    } else {
      stop('fData(x)$chrName has to be of class character or factor!\n')
    }
    if (selChr %in% c('both','all')) {
      plotCna(x,sel.sam=i,chrLabels=chrname,main=sample)
    } else {
      sel.chr <- chr[chrname %in% selChr]
      chrLab <- chrname[chrname %in% selChr]
      plotCnaChr(x,sel.chr=sel.chr,sel.sam=i,chrLab=chrLab)
    }
    if (selChr=='both') {
      for (j in 1:length(chr)) {
        plotCnaChr(x,sel.chr=chr[j],sel.sam=i,chrLab=chrname[j])
      }
    }
  }
}
)

#
# EXPORT TO TABLE
#

setGeneric("toTable",function (x) standardGeneric("toTable"))

setMethod("toTable",signature(x='cghCall'),
  function (x) {
    if (ncol(x)!=1) stop('Subset the cghCall object in order to select only one sample\n')
    browser()
    ans <- data.frame(features=featureNames(x), chromosome=fData(x)$chrName, start=fData(x)$Start, end=fData(x)$End,
                  score=as.numeric(copynumber(x)), probLoss=as.numeric(probloss(x)),
                  probAmp=as.numeric(probamp(x)), cna=as.numeric(calls(x)))
    ans
  }
)
