dens.data.frame <- function(x,main='',ylab='Density',...) {
  dens.matrix(x,main=main,ylab=ylab,...)
}
