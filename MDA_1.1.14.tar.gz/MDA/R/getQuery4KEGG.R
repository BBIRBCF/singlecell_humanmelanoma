getQuery4KEGG <- function (ids) {
#Get URL for KEGG gene set
    blanks <- ids == "&nbsp;"
    ids <- gsub(" ","0",format(ids,width=5,justify='right'))  #zero-fill
    out <- paste("http://www.genome.jp/dbget-bin/www_bget?pathway+ko",ids,sep="")
    out[blanks] <- "&nbsp;"
    return(out)
}
