bgseaPipeline <- function(x,d,geneinfo,orderby,decreasing=TRUE,GO=TRUE,KEGG=TRUE,BROAD='',fdr=.05,FilterEntrezDupl=TRUE,minGene=10,maxGene=500,dlevels,savexls=TRUE,outputdir,prefix='') {
require("GSEABase")
require("annotate")
require("genefilter")
require("KEGG.db")
require("GO.db")
require("BGSEA")
gseaanno <- paste("require('GeneSet",annotation(x),"')",sep='',collapse='')
eval(parse(text=gseaanno))

if (!is.character(BROAD)) BROAD <- paste(as.character(BROAD),collapse='')
if (!missing(outputdir)) setwd(outputdir)
if (nrow(d)!=nrow(x)) warning('x and d do not have the same number of rows. Make sure it is not an mistake!')
if (is.null(row.names(d))) row.names(d) <- featureNames(x)
if (!missing(orderby)) { if (!(orderby %in% names(geneinfo))) stop('name specified in orderby is not in names(geneinfo)') }
if (missing(dlevels)) dlevels <- unique(as.vector(d))
setid <- NA   #define NA variable to avoid warning

if (FilterEntrezDupl) {
  cat('Selecting genes with Entrez ID and removing duplicates... ')
  x <- nsFilter(x,require.entrez=TRUE,remove.dupEntrez=TRUE,var.func=IQR,var.filter=FALSE)$eset
  d <- d[featureNames(x),]
  cat('Done.\n')
}

tabout <- list()

# KEGG
if (KEGG) {
  cat('KEGG:     Loading GeneSetCollection... ')
  e <- paste("data(",annotation(x),"GSCKEGG)",sep=''); eval(parse(text=e)) #load GeneSetCollection
  cat('Performing Bayesian GSEA... ')
  e <- paste("tabout$KEGG <- bgsea(d=d,gsc=",annotation(x),"GSCKEGG,fdr=fdr,minGene=minGene,maxGene=maxGene,dlevels=dlevels)",sep='')
  eval(parse(text=e))
  e <- paste("setid <- unlist(lapply(",annotation(x),"GSCKEGG[names(tabout$KEGG$genelist)],function(x) { return(setIdentifier(x)) }))",sep='')
  eval(parse(text=e))
  cat('Annotating genes... ')
  tabout$KEGGgenelist <- bgseaAnnotate(tabout$KEGG,annotation(x),geneinfo=geneinfo,maxSets=1000)
  cat('Saving to xls file... ')
  tabout$KEGG <- data.frame(set=names(tabout$KEGG$genelist),KEGGterm=setid,nbGenes=tabout$KEGG$nbGenes,PercDE=round(100*tabout$KEGG$PercDE,1),RefPercDE=round(100*tabout$KEGG$RefPercDE,1),probEnriched=round(tabout$KEGG$probEnriched,3),isEnriched=tabout$KEGG$isEnriched,probDEGenes=round(tabout$KEGG$probDEGenes,3),hasDEGenes=tabout$KEGG$hasDEGenes)
  names(tabout$KEGG) <- sub('probEnriched.','',names(tabout$KEGG))
  names(tabout$KEGG) <- sub('isEnriched.','',names(tabout$KEGG))
  if (!missing(orderby)) {
    seqsetid <- cumsum(c(TRUE,tabout$KEGGgenelist$setid[-1]!=tabout$KEGGgenelist$setid[-nrow(tabout$KEGGgenelist)]))
    seqsetid <- seqsetid[order(tabout$KEGGgenelist[,orderby],decreasing=decreasing)]
    tabout$KEGGgenelist <- tabout$KEGGgenelist[order(tabout$KEGGgenelist[,orderby],decreasing=decreasing),]
    tabout$KEGGgenelist <- tabout$KEGGgenelist[order(seqsetid),]
  }
  if (!is.null(tabout$KEGG) && savexls) {
    dirname <- paste(prefix,'GSEA_KEGG',sep='')
    dir.create(dirname,showWarnings=FALSE)
    write.table(tabout$KEGG,file.path(dirname,paste(dirname,'.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
    write.table(tabout$KEGGgenelist,file.path(dirname,paste(prefix,'GSEA_KEGGgenelist.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
  }
  cat('Done.\n')
}

# GO
if (GO) {
  cat('GO:       Loading GeneSetCollection... ')
  e <- paste("data(",annotation(x),"GSCGO)",sep=''); eval(parse(text=e)) #load GeneSetCollection
  cat('Performing Bayesian GSEA... ')
  e <- paste("tabout$GO <- bgsea(d=d,gsc=",annotation(x),"GSCGO,fdr=fdr,minGene=minGene,maxGene=maxGene,dlevels=dlevels)",sep='')
  eval(parse(text=e))
  e <- paste("setid <- unlist(lapply(",annotation(x),"GSCGO[names(tabout$GO$genelist)],function(x) { return(setIdentifier(x)) }))",sep='')
  eval(parse(text=e))
  cat('Annotating genes... ')
  tabout$GOgenelist <- bgseaAnnotate(tabout$GO,annotation(x),geneinfo=geneinfo,maxSets=1000)
  cat('Saving to xls file... ')
  tabout$GO <- data.frame(set=names(tabout$GO$genelist),GOterm=setid,nbGenes=tabout$GO$nbGenes,PercDE=round(100*tabout$GO$PercDE,1),RefPercDE=round(100*tabout$GO$RefPercDE,1),probEnriched=round(tabout$GO$probEnriched,3),isEnriched=tabout$GO$isEnriched,probDEGenes=round(tabout$GO$probDEGenes,3),hasDEGenes=tabout$GO$hasDEGenes)
  names(tabout$GO) <- sub('probEnriched.','',names(tabout$GO))
  names(tabout$GO) <- sub('isEnriched.','',names(tabout$GO))
  if (!missing(orderby)) {
    seqsetid <- cumsum(c(TRUE,tabout$GOgenelist$setid[-1]!=tabout$GOgenelist$setid[-nrow(tabout$GOgenelist)]))
    seqsetid <- seqsetid[order(tabout$GOgenelist[,orderby],decreasing=decreasing)]
    tabout$GOgenelist <- tabout$GOgenelist[order(tabout$GOgenelist[,orderby],decreasing=decreasing),]
    tabout$GOgenelist <- tabout$GOgenelist[order(seqsetid),]
  }
  if (!is.null(tabout$GO) && savexls) {
    dirname <- paste(prefix,'GSEA_GO',sep='')
    dir.create(dirname,showWarnings=FALSE)
    write.table(tabout$GO,file.path(dirname,paste(dirname,'.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
    write.table(tabout$GOgenelist,file.path(dirname,paste(prefix,'GSEA_GOgenelist.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')
  }
  cat('Done.\n')
}

#BROAD
if (BROAD!='') {
  for (i in 1:5) {
    if (length(grep(as.character(i),BROAD))>0) {
      cat('BROAD c',as.character(i),': Loading GeneSetCollection... ',sep='')
      e <- paste("data(",annotation(x),"GSCBROADc",i,")",sep=''); eval(parse(text=e)) #load GeneSetCollection
      cat('Performing Bayesian GSEA... ')
      e <- paste("tabout$BROADc",i," <- bgsea(d=d,gsc=",annotation(x),"GSCBROADc",i,",fdr=fdr,minGene=minGene,maxGene=maxGene,dlevels=dlevels)",sep='')
      eval(parse(text=e))

      cat('Annotating genes... ')
      e <- paste("tabout$BROADc",i,"genelist <- bgseaAnnotate(tabout$BROADc",i,",annotation(x),geneinfo=geneinfo,maxSets=1000)",sep='')
      eval(parse(text=e))
      cat('Saving to xls file... ')
      e <- paste("tabout$BROADc",i," <- data.frame(set=names(tabout$BROADc",i,"$genelist),nbGenes=tabout$BROADc",i,"$nbGenes,PercDE=round(100*tabout$BROADc",i,"$PercDE,1),RefPercDE=round(100*tabout$BROADc",i,"$RefPercDE,1),probEnriched=round(tabout$BROADc",i,"$probEnriched,3),isEnriched=tabout$BROADc",i,"$isEnriched,probDEGenes=round(tabout$BROADc",i,"$probDEGenes,3),hasDEGenes=tabout$BROADc",i,"$hasDEGenes)",sep='')
      eval(parse(text=e))
      e <- paste("names(tabout$BROADc",i,") <- sub('probEnriched.','',names(tabout$BROADc",i,"))",sep=''); eval(parse(text=e))
      e <- paste("names(tabout$BROADc",i,") <- sub('isEnriched.','',names(tabout$BROADc",i,"))",sep=''); eval(parse(text=e))

      if (!missing(orderby)) {
        e <- paste("seqsetid<- cumsum(c(TRUE,tabout$BROADc",i,"genelist$setid[-1]!=tabout$BROADc",i,"genelist$setid[-nrow(tabout$BROADc",i,"genelist)]))",sep='')
        eval(parse(text=e))
        e <- paste("seqsetid <- seqsetid[order(tabout$BROADc",i,"genelist[,orderby],decreasing=decreasing)]",sep=''); eval(parse(text=e))
        e <- paste("tabout$BROADc",i,"genelist <- tabout$BROADc",i,"genelist[order(tabout$BROADc",i,"genelist[,orderby],decreasing=decreasing),]",sep=''); eval(parse(text=e))
        e <- paste("tabout$BROADc",i,"genelist <- tabout$BROADc",i,"genelist[order(seqsetid),]",sep=''); eval(parse(text=e))
      }
      e <- paste("!is.null(tabout$BROADc",i,") && savexls",sep='')
      if (eval(parse(text=e))) {
        dirname <- paste(prefix,'GSEA_BROADc',i,sep='')
        dir.create(dirname,showWarnings=FALSE)
        e <- paste("write.table(tabout$BROADc",i,",file.path(dirname,paste(dirname,'.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')",sep='')
        eval(parse(text=e))
        e <- paste("write.table(tabout$BROADc",i,"genelist,file.path(dirname,paste(prefix,'GSEA_BROADc",i,"genelist.xls',sep='')),row.names=FALSE,col.names=TRUE,dec=',',sep='\t')",sep='')
        eval(parse(text=e))
      }
      cat('Done.\n')
    }
  }
}

return(tabout)
}
