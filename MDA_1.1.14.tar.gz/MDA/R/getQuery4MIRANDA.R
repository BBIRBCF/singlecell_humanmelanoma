getQuery4MIRANDA <- function (ids) {
#Get directory for miRBase
    blanks <- ids == "&nbsp;"
    out <- paste("http://microrna.sanger.ac.uk/cgi-bin/targets/v5/hit_list.pl?genome_id=native&mirna_id=",ids,sep='')
    out[blanks] <- "&nbsp"
    return(out)
}
