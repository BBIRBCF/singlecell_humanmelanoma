dens.default <- function(x,main='',ylab='Density',...) { plot(density(x),main=main,ylab=ylab,...) }
