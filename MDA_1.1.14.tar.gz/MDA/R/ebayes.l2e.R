ebayes.l2e <- function(x,group,l2e=FALSE,l2e.adjP=FALSE,wl2e=TRUE,wl2e.adjP=TRUE,ttest=FALSE,wilctest=FALSE,sd.tstat=FALSE,fdr=0.05,fmethod='kernel',maxrew=10,nufix) {

# INPUT
# x: normalized expression data (genes in rows, biological samples in columns). If a vector is supplied it is treated as the test statistic and only partial mixture methods (L2E, WL2E) are available
# group: vector of 1's and 2's indicating the group to which the columns of x belong
# l2e: use L2E to estimate null distrib
# l2e.adjP: use L2E to estimate null distrib, Wald test stat and Benjamini&Hochberg's p-value adjustment
# wl2e: use weighted L2E to estimate null distrib
# wl2e.adjP: use weighted L2E to estimate null distrib, Wald test stat and Benjamini&Hochberg's p-value adjustment
# ttest: use two-sample t-tests (assuming equal variances) with Benjamini&Hochberg's p-value adjustment
# wilctest: use two-sample Wilcoxon tests (asymptotic p-vals computed, with continuity correction) with BH p-value adjustment
# sd.tstat: if FALSE, the test stat for L2E and WL2E is the difference between the 2 group means. If TRUE, it is divided by its SD as in a regular t-test.
# fdr: desired FDR level
# fmethod: 'kernel' to use kernel estimate of the overall distribution (currently it's the only option available)
# maxrew: maximum number of iterative re-weightings in the weighted L2E fitting
# nufix: if specified, the partial mixture fits a Student's t component with nufix degrees of freedom
  
if (l2e==F&l2e.adjP==F&wl2e==F&wl2e.adjP==F&ttest==F&wilctest==F) stop('At least one of l2e,l2e.adjP,wl2e,wl2e.adjP,ttest or wilctest has to be set to TRUE')
if (fdr>=1 | fdr<=0) stop('fdr must be between 0 and 1')
if (is.matrix(x)) {
  if (missing(group)) stop('If x is a matrix the argument group must be provided')
  if (length(table(group))>2) stop('groups can only indicate 2 groups') 
  if (sum((group!=1)&&(group!=2))>0) { group <- as.numeric(factor(group)); warning('group labels converted to 1,2') }
}
if (!missing(nufix)) require(quantreg)

#Load library & Define useful functions
logit <- function(x) { log((x+.1)/(1-x+.1)) }
pnorm.mix <- function(x,mu,sd,probs) {  colSums(probs * pnorm(matrix(rep(x,length(mu)),nrow=length(mu),byrow=T),mu,sd)) }
dnorm.mix <-function(x,mu,sd,probs,log) {colSums(probs*dnorm(matrix(rep(x,length(mu)),nrow=length(mu),byrow=T),mu,sd,log))}
dnct <- function(x,v,mu,sig) { return( dt((x-mu)/sqrt(sig),df=v)/sqrt(sig) ) }

twilc <- function(i,x,group) { return(wilcox.test(as.numeric(x[i,group==1]),as.numeric(x[i,group==2]))$statistic) }
pwilc <- function(i,x,group) { return(wilcox.test(as.numeric(x[i,group==1]),as.numeric(x[i,group==2]))$p.value) }


#Obtain test statistics
if (!is.vector(x)) {
  n <- as.integer(table(group)); m1 <- rowMeans(x[,group==1],na.rm=TRUE); m2 <- rowMeans(x[,group==2],na.rm=TRUE)
  v1 <- (rowMeans(x[,group==1]^2,na.rm=TRUE)-m1^2) * n[1]/(n[1]-1); v2 <- (rowMeans(x[,group==2]^2,na.rm=TRUE)-m2^2) * n[2]/(n[2]-1)
  s <- sqrt(((n[1]-1)*v1+(n[2]-1)*v2)/(sum(n)-2))*sqrt(1/n[1]+1/n[2])
  if (sd.tstat==TRUE) {
    fudge <- quantile(s,probs=.01)
    tstat <- (m1-m2)/s; tstat[s<fudge] <- (m1[s<fudge]-m2[s<fudge])/fudge
  } else {
    tstat <- m1-m2
  }
  if (ttest==T) { tstat.ttest <- (m1-m2)/s } else { tstat.ttest <- NA }
  if (any(tstat==0)) warning('Some tstat values are equal to 0. Check that your data has been correctly imported and processed!')
} else { tstat <- x; tstat.ttest <- NA }

#Estimate overall distribution
if (l2e==T | wl2e==T) {
  if (missing(nufix)) {
    f <- density(tstat,na.rm=TRUE)     #use Normal kernel if f0 assumed to be normal
    f <- approx(f$x,f$y,xout=tstat)$y
  } else {
    f <- akj(x=tstat,z=tstat,iker1=1)$dens  #use Cauchy kernel if f0 assumed to be t
  }
} else { f <- NA }

#Estimate null distribution
if (missing(nufix)) {
  if (l2e==T | l2e.adjP==T) {
    t0.l2e <- mpdc(tstat); mu0.l2e <- t0.l2e$m; sd0.l2e <- sqrt(t0.l2e$sig); w0.l2e <- t0.l2e$w
  }
  if (wl2e==T | wl2e.adjP==T) {
    t0.wl2e <- rewupdc(tstat, maxrew=maxrew, tol=.01)
    mu0.wl2e <- t0.wl2e$m; sd0.wl2e <- sqrt(t0.wl2e$sig); w0.wl2e <- t0.wl2e$w
  }
} else {
  if (l2e==T | l2e.adjP==T) {
    mu0.l2e <- 0; sd0.l2e <- 1
    w0.l2e <- wupdc.findw(tstat, nu=nufix, weight=FALSE, f0='t')
  }
  if (wl2e==T | wl2e.adjP==T) {
    mu0.wl2e <- 0; sd0.wl2e <- 1
    w0.wl2e <- wupdc.findw(tstat, nu=nufix, weight=TRUE, f0='t')
  }
}

# Determine differentially expressed genes based on posterior prob of DE
if (l2e==T) {
  if (missing(nufix)) {
    l2e.pde <- 1 - w0.l2e*dnorm(tstat,mu0.l2e,sd0.l2e)/f
  } else {
    l2e.pde <- 1 - w0.l2e*dt(tstat,df=nufix)/f
  }
  l2e.pde <- ifelse(l2e.pde>1,1,l2e.pde); l2e.pde <- ifelse(l2e.pde<0,0,l2e.pde)
  r.l2e <- find.threshold(l2e.pde,fdr)$threshold
  rej.l2e <- ((l2e.pde>r.l2e) & (tstat>mu0.l2e)) - ((l2e.pde>r.l2e) & (tstat<mu0.l2e))
} else { l2e.pde <- rej.l2e <- NA }
if (wl2e==T) {
  if (missing(nufix)) {
    wl2e.pde <- 1 - w0.wl2e*dnorm(tstat,mu0.wl2e,sd0.wl2e)/f
  } else {
    wl2e.pde <- 1 - w0.wl2e*dt(tstat,df=nufix)/f
  }
  wl2e.pde <- ifelse(wl2e.pde>1,1,wl2e.pde); wl2e.pde <- ifelse(wl2e.pde<0,0,wl2e.pde)
  r.wl2e <- find.threshold(wl2e.pde,fdr)$threshold
  rej.wl2e <- ((wl2e.pde>r.wl2e) & (tstat>mu0.wl2e)) - ((wl2e.pde>r.wl2e) & (tstat<mu0.wl2e))
} else { wl2e.pde <- rej.wl2e <- NA }

# Determine differentially expressed genes based on P-value adjustment
if ((l2e.adjP==F) & (l2e==F)) { mu0.l2e <- sd0.l2e <- w0.l2e <- NA }
if ((wl2e.adjP==F) & (wl2e==F)) { mu0.wl2e <- sd0.wl2e <- w0.wl2e <- NA }
if(l2e.adjP==T){
  wald.l2e <- (tstat-mu0.l2e)/sd0.l2e
  if (missing(nufix)) {
    l2e.adjP <- p.adjust(2*(1-pnorm(abs(wald.l2e))),method='BH')
  } else {
    l2e.adjP <- p.adjust(2*(1-pt(abs(wald.l2e),df=nufix)),method='BH')
  }
  rej.l2e.adjP <- (l2e.adjP<(fdr/w0.l2e) & tstat>mu0.l2e) - (l2e.adjP<(fdr/w0.l2e) & tstat<mu0.l2e)
} else {l2e.adjP <- rej.l2e.adjP <- NA}
if(wl2e.adjP==T){
  wald.wl2e <- (tstat-mu0.wl2e)/sd0.wl2e
  if (missing(nufix)) { 
    wl2e.adjP <- p.adjust(2*(1-pnorm(abs(wald.wl2e))),method='BH')
  } else {
    wl2e.adjP <- p.adjust(2*(1-pt(abs(wald.wl2e),df=nufix)),method='BH')    
  }
  rej.wl2e.adjP <- (wl2e.adjP<(fdr/w0.wl2e) & tstat>mu0.wl2e) - (wl2e.adjP<(fdr/w0.wl2e) & tstat<mu0.wl2e)
} else {wl2e.adjP <- rej.wl2e.adjP <- NA}
if (ttest==T) {
  ttest.adjP <- 2*(1-pt(abs(tstat.ttest),df=sum(n)-2));
  ttest.adjP <- p.adjust(ttest.adjP,method='BH')
  rej.ttest <- (ttest.adjP<fdr & tstat>0) - (ttest.adjP<fdr & tstat<0)
} else { ttest.adjP <- rej.ttest <- NA }
if (wilctest==T) {
  tstat.wilc <- sapply(1:nrow(x),'twilc',x=x,group=group)
  wilctest.adjP <- sapply(1:nrow(x),'pwilc',x=x,group=group)
  wilctest.adjP <- p.adjust(wilctest.adjP,method='BH')
  rej.wilctest <- (wilctest.adjP<fdr & tstat.wilc>mean(tstat.wilc)) - (wilctest.adjP<fdr & tstat.wilc<mean(tstat.wilc))
} else { tstat.wilc <- wilctest.adjP <- rej.wilctest <- NA }

return(list(tstat=tstat,l2e.pde=l2e.pde,rej.l2e=rej.l2e,wl2e.pde=wl2e.pde,rej.wl2e=rej.wl2e,l2e.adjP=l2e.adjP, rej.l2e.adjP=rej.l2e.adjP, wl2e.adjP=wl2e.adjP, rej.wl2e.adjP=rej.wl2e.adjP,tstat.ttest=tstat.ttest,ttest.adjP=ttest.adjP,rej.ttest=rej.ttest,tstat.wilc=tstat.wilc,wilctest.adjP=wilctest.adjP,rej.wilctest=rej.wilctest,mu0.l2e=mu0.l2e,sd0.l2e=sd0.l2e,w0.l2e=w0.l2e,mu0.wl2e=mu0.wl2e,sd0.wl2e=sd0.wl2e,w0.wl2e=w0.wl2e,f=f))

}
