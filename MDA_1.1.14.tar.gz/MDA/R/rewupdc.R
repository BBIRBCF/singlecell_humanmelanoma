rewupdc <- function(x, mu0, sig0, mu, sig, w, wmax=1, maxrew=10, tol=.01) {
# rewupdc: Re-weighted L2E
# mu0: mean of the weighting distribution. Defaults to the mean of an non-weighted L2E fit
# sig0: variance of the weighting distribution. Defaults to the var of a non-weighted L2E fit
# mu: initial guess (defaults to mu0)
# sig: initial guess (defaults to sig0)
# w: initial guess (defaults to .9*wmax)
# wmax: upper bound for w (default wmax=1)
# maxrew: iterative fitting stops when maxrew fits have been performed or when the change in the parameters is smaller than tol
# tol: iterative fitting stops when maxrew fits have been performed or when the change in the parameters is smaller than tol

if (!is.vector(x)) stop("x must be a vector")
if (missing(mu0) | missing(sig0)) { z <- mpdc(x); mu0 <- z$m; sig0 <- z$sig }
if (sig0<0) stop('sig0 must be positive')
if (missing(mu)) { mu <- mu0 }; if (missing(sig)) { sig <- sig0 }; if (missing(w)) { w <- .9*wmax }

logit <- function(x) { log((x+.1)/(1-x+.1)) }

fit <- wupdc(x,mu0,sig0)
eps <- (mu-fit$m)^2 + (log(sig/fit$sig))^2 + (logit(w)-logit(fit$w))^2
mu <- fit$m; sig <- fit$sig; w <- fit$w
i <- 1
while (eps>tol & i<=maxrew) {
  fit <- wupdc(x,mu,sig)
  eps <- (mu-fit$m)^2 + (log(sig/fit$sig))^2 + (logit(w)-logit(fit$w))^2
  mu <- fit$m; sig <- fit$sig; w <- fit$w
  i <- i+1
}

if ((i==maxrew) && (eps>tol)) { warning('Iteration limit reached without achieving convergence') }

return(list(m=mu,sig=sig,w=w,min=fit$min,wmax=fit$wmax,niter=i))

}
