tab2latex <- function(x,y,colper=FALSE,rowper=FALSE,caption='',label='',file='',include.rownames=FALSE,...) {
#create bivariate contingency table and print to a file in LaTeX format
  ans <- table(x,y)
  if (colper==TRUE) {
    ans2 <- matrix(paste(ans,' (',round(100*t(t(ans)/colSums(ans)),1),'%)',sep=''),ncol=ncol(ans))
    colnames(ans2) <- colnames(ans); rownames(ans2) <- rownames(ans)
   } else if (rowper==TRUE) {
    ans2 <- matrix(paste(ans,' (',round(100*ans/colSums(ans),1),'%)',sep=''),ncol=ncol(ans))
    colnames(ans2) <- colnames(ans); rownames(ans2) <- rownames(ans)
  }
  if (missing(file)) {
    return(xtable(ans2,caption=caption,label=label))
  } else {
    print(xtable(ans2,caption=caption,label=label),file=file,include.rownames=include.rownames,...)
  }
}
