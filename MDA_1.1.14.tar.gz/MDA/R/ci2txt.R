ci2txt <- function(x,digits=2) { x <- round(x,digits); paste('(',x[,1],',',x[,2],')',sep='') }
