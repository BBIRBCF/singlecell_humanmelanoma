hclustSample <- function(eset,maxClus=10,distance="euclid",method="average",bootstrap=TRUE,nTimes=500) {
#Agglomorative Hierarchical Clustering. Selects number of clusters maximizing median silhouette.
# INPUT
# - eset: ExpressionSet with values to perform the clustering
# - maxClus: maximum number of clusters
# - distance: metric to measure distances between samples. Passed on to function 'distancematrix' and 'cutHclust'
# - method: linkage method
# - bootstrap: set to TRUE to cluster bootstrap samples. Useful to assess cluster robustness.
# - nTimes: number of boostrap samples (passed on to BootstrapClusterTest)
# OUTPUT: list with following elements
# - cluster: agglomorative cluster labels
# - nclust: number of clusters maximizing median silhouette for agglomorative clustering
# - medianSil: vector with median Silhouette for each cluster size
# - hclustOut: agglomorative cluster (object of class 'hclust', as returned by function 'hclust')
# - boot: bootstrap sample clustering, as returned by BootstrapClusterTest
  require(ClassDiscovery)
  require(hopach)

  mydist <- distancematrix(t(exprs(eset)),distance)
  cluster <- matrix(NA,nrow=ncol(eset),ncol=maxClus-1)
  medianSil <- double(maxClus-1); names(medianSil) <- as.character(2:maxClus)
  for (k in 2:maxClus) {
    cluster[,k-1] <- cutHclust(eset,k=k,method=method,metric=distance)
    medianSil[k-1] <- labelstomss(labels=cluster[,k-1],dist=mydist,hierarchical=FALSE)  #median split silhouette
  }
  nclust <- 1+which.max(medianSil)
  cluster <- cluster[,nclust-1]
  hclustOut <- hclust(dist(t(exprs(eset)),distance),method)

  if (bootstrap) {
    boot <- BootstrapClusterTest(eset,cutHclust,nTimes=nTimes,k=nclust,metric=distance,method=method)
  } else {
    boot <- NA
  }
  return(list(cluster=cluster,nclust=nclust,medianSil=medianSil,hclustOut=hclustOut,boot=boot)) 
}
