normqc <- function(dir,sample.info='sampleinfo.txt',outputdir,filename='normalized_data',xlsformat=FALSE,dec='.',summarization='rma',celimage=FALSE,normplots=TRUE,qc=TRUE,chipplot=FALSE,verbose=TRUE,maplots=FALSE,cdfname=NULL,myTarget='probeset',normalize=TRUE,forceOligoPkg=FALSE) {
#Pre-process Affymetrix data via RMA or GCRMA and obtain quality control diagnostics
require(affy)

if (missing(outputdir)) outputdir <- dir
if (summarization!='mas5' & summarization!='rma' & summarization!='gcrma' & summarization!='none') stop('Summarization must be rma, gcrma or none')

#Read data
cat("Reading sample information... ")
setwd(dir)
sample.info <- read.csv(sample.info,header=TRUE,sep='\t',dec=dec)
if (sum(names(sample.info)=='filename')>0) {
  fnames <- as.character(sample.info$filename)
} else {
  fnames <- as.character(sample.info[,1])
}
fnames <- sub(' $','',fnames)
cat("Done\n \n")

cat("Reading Affy data... ")
if (sum(names(sample.info)=='samplename')>0) { samplenames <- as.character(sample.info$samplename) } else { samplenames <- fnames }
pheno <- new("AnnotatedDataFrame", data=sample.info, dimLabels=c("rowNames", "columnNames"))
sampleNames(pheno) <- samplenames
celdata <- ReadAffy(filenames=fnames,phenoData=pheno,verbose=verbose,sampleNames=samplenames)
cat("Done\n \n")

#Test if we have the cdf
cdfExists <- suppressWarnings(library(paste(annotation(celdata),'cdf',sep=''),character.only=TRUE,logical.return=TRUE,warn.conflicts = FALSE))

#Normalization
if (summarization!='none') {
  if ((cdfExists | !is.null(cdfname)) & forceOligoPkg==FALSE)  {
    cat("Pre-processing data... \n")
    if (summarization=='mas5') {
      x <- mas5(celdata)
    } else if (summarization=='rma') {
      x <- just.rma(filenames=fnames,verbose=verbose,phenoData=pheno,cdfname=cdfname,normalize=normalize)
    } else if (summarization=='gcrma') {
      require(gcrma)
      x <- just.gcrma(filenames=fnames,verbose=verbose,phenoData=pheno,cdfname=cdfname,normalize=normalize)
    }
    cat("Done\n \n")
  } else {
    if (summarization!='none') {
      cat("Pre-processing data... \n")
      if (summarization=='rma') {
        if (!normalize) warning('Data has been normalized although it has been asked not to do so (trying specifying a cdfname)!')
        require(oligo)
        rawData <- read.celfiles(filenames=fnames)
        if (class(rawData) %in% c('ExonFeatureSet','GeneFeatureSet')) {
          x <- oligo::rma(rawData,target=myTarget)
        } else {
          x <- oligo::rma(rawData)
        }
        phenoData(x) <- pheno
      } else {
        stop('Only rma summarization is implemented for chips without cdf library.')
      }
    }
    cat("Done\n \n")
  }
  setwd(outputdir)
  cat(sprintf("Saving normalized data in %s.RData... ",filename))
  if (xlsformat) {
    write.table(data.frame(featureNames(x),exprs(x)),paste(filename,'.xls',sep=''),row.names=FALSE,col.names=c("P_SET",sampleNames(x)),sep='\t',dec=',')
  } else {
    save(x,file=paste(filename,'.RData',sep=''),compress='bzip2')
  }
  cat("Done\n \n")
}


setwd(outputdir)

if (celimage) {
  cat("Producing CEL images... ")
  pdf('CELimage.pdf')
  palette.gray <- c(rep(gray(0:10/10),times=seq(1,41,by=4)))
  image(celdata,col=palette.gray)
  dev.off()
  cat("Done\n \n")
}

#Normalization plots
if (normplots & normalize) {
  cat("Producing normalization plots... ")
  pdf('boxplot_CEL.pdf')
  if (cdfExists) {
    boxplot(celdata,ylab='Raw data',outline=FALSE,las=2,cex.axis=0.7)
  } else {
    boxplot(rawData,ylab='Raw data',outline=FALSE,las=2,col='lightgrey')
  }
  dev.off()

  if (summarization!='none') {
    pdf('boxplot_normdata.pdf')
    boxplot(data.frame(exprs(x)),ylab='Normalized data',outline=FALSE)
    dev.off()
  }
  cat("Done\n \n")
}

#MA plots
if (maplots) {
  cat("Producing MA plots... ")
  pdf('MAplot_CEL.pdf')
  MAplot(celdata, plot.method = "smoothScatter")
  dev.off()

  if (summarization!='none') {
    pdf('MAplot_normdata.pdf')
    MAplot(x, plot.method = 'smoothScatter')
    dev.off()
  }
  cat("Done\n \n")
}

#Quality control plots
if (qc) {
  cat("Producing RNA degradation plot... ")
  try(RNAdeg <- AffyRNAdeg(celdata))
  if (class(RNAdeg)!='try-error') {
    pdf('qc_RNAdeg.pdf')
    plotAffyRNAdeg(RNAdeg)
    dev.off()
    cat("Done\n \n")
    cat("Writing QC metrics and RNA degradation information to file 'qc_metrics.txt'... ")
    qcmetrics <- data.frame(t(apply(exprs(celdata),2,'quantile',probs=c(.5,.95))),t(summaryAffyRNAdeg(RNAdeg)))
    names(qcmetrics) <- c('median','P95','degradation.slope','slope.pvalue')
    qcmetrics$ratio <- qcmetrics$P95/qcmetrics$median
    qcmetrics <- qcmetrics[,c(1,2,5,3,4)]
    write.table(data.frame(sampleNames(celdata),qcmetrics),row.names=FALSE,col.names=c('array',names(qcmetrics)),'qc_metrics.xls',sep='\t',dec=',')
    cat("Done\n \n")
  } else {
    warning('Could not create degradation plot & qc metrics\n\n')
  }

  cat("Producing NUSE Quality Control plot... ")
  require("affyPLM")
  try(plm1 <- fitPLM(celdata),silent=TRUE)  #fit robust model similar to RMA
  if (class(plm1)!='try-error') {
    pdf('qc_NUSE.pdf')
    NUSE(plm1,ylab='Standard Error of Quantification',outline=FALSE,las=2,cex.axis=0.2,cex.col=1:2)
    dev.off()
    if (chipplot) {
      cat("Producing chip residual plots... ")
      pdf("chipres.pdf")
      image(plm1,type='sign.resids')
      dev.off()
      cat("Done \n \n")
    }
  } else {
    warning('Could not produce NUSE plots')
  }
  cat("Done\n \n")

}

}
