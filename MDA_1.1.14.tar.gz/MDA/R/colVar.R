colVar <- function(x,...) { return((colMeans(x^2,...)-colMeans(x,...)^2)*nrow(x)/(nrow(x)-1)) }
