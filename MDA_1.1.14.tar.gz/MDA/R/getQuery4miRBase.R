getQuery4miRBase <- function (ids) {
#Get directory for miRBase
    blanks <- ids == "&nbsp;"
    out <- paste("http://microrna.sanger.ac.uk/cgi-bin/sequences/query.pl?terms=",ids,sep='')
    out[blanks] <- "&nbsp"
    return(out)
}
