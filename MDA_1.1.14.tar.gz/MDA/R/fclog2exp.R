fclog2exp <- function(x,base='2') { ans <- sign(x)*as.numeric(base)^abs(x); ans[ans==0] <- 1; return(ans) }
