kaplan <- function(event,time,gene,geneName='',cut,numgroups,groups,timelimit,xlab='Time to event',ylab='Survival',legendpos='bottomright',legendcex=0.7,col,main='',lty=1,...) {
  require(Hmisc)
  require(survival)
  getHr <- function(x,item) round(exp((abs(coef(x)[item])))*sign(coef(x)[item]),3)
  getCol <- function(x) {if (x==2) c('darkgreen','red') else if (x==3) c('darkgreen','gray','red') else if (x==4) c('darkgreen','lightgreen','pink','red') else if (x==5) c('darkgreen','lightgreen','gray','pink','red') else if (x==6) c('darkgreen','green','lightgreen','pink','red','darkred')}
  #control errors
  stopifnot(length(event) == length(time))
  if (missing(groups)) stopifnot(length(event) == length(gene))
  stopifnot(!missing(numgroups))
  stopifnot(numgroups %in% c(2,3,4,5,6))
  stopifnot(missing(cut) | missing(groups))
  if (!missing(cut)) stopifnot(length(cut)==numgroups-1)
  if (!missing(groups)) {
    stopifnot(length(levels(groups)) == numgroups)
    stopifnot(class(groups)=='factor')
      if (missing(groups)) stopifnot(length(groups)==length(gene))
  }
  #make groups
  if (!missing(groups)) {
    gene.cut <- groups
  } else {
    if (missing(cut)) {
      cut <- quantile(gene,probs=(1:(numgroups-1))/numgroups)
    } 
    if (numgroups==2) {
      gene.cut <- ifelse(gene<cut,1,2)
      labels <- paste(geneName,c('-','+'))
    } else if (numgroups==3) {
      gene.cut <- ifelse(gene<cut[1],1,ifelse(gene>=cut[2],3,2))
      labels <- paste(geneName,c('-','uk','+'))
    } else if (numgroups==4) {
      gene.cut <- ifelse(gene<cut[1],1,ifelse(gene>=cut[1] & gene<cut[2],2,ifelse(gene>=cut[3],4,3)))
      labels <- paste(geneName,c('low','med.low','med.high','high'))
    } else if (numgroups==5) {
      gene.cut <- ifelse(gene<cut[1],1,ifelse(gene>=cut[1] & gene<cut[2],2,ifelse(gene>=cut[2] & gene<cut[3],3,ifelse(gene>=cut[4],5,4))))
      labels <- paste(geneName,c('low','med.low','med','med.high','high'))
    } else if (numgroups==6) {
      gene.cut <- ifelse(gene<cut[1],1,ifelse(gene>=cut[1] & gene<cut[2],2,ifelse(gene>=cut[2] & gene<cut[3],3,ifelse(gene>=cut[3] & gene<cut[4],4,ifelse(gene>=cut[5],6,5)))))
      labels <- paste(geneName,c('LOW','low','med.low','med.high','high','HIGH'))
    }
    gene.cut <- factor(gene.cut,labels=labels)
  }
  #set time limit
  if (!missing(timelimit)) {
    event[time>timelimit] <- 0
    xlim <- c(0,timelimit)
  } else {
    xlim <- c(0,max(time,na.rm=T))
  }
  #fit model
  s <- Surv(time,event)
  myFit <- survfit(s~gene.cut)
  sub <- paste('(n=',length(event),')',sep='')
  #plot
  if (missing(col)) col <- getCol(numgroups)
  plot(myFit,col=col,sub=sub,xlim=xlim,xlab=xlab,ylab=ylab,main=main,lty=lty,...)
  numevents <- table(gene.cut,as.logical(event))[,'TRUE']
  mylegend <- paste(levels(gene.cut),' (n=',table(gene.cut),', events=',numevents,')',sep='')
  legend(legendpos,legend=mylegend,col=col,cex=legendcex,lty=lty)
  if (missing(groups)) {
    ans <- list('Gene as continuous var'=coxUnivTable(time,event,data.frame(x=gene)), 'Gene as categorical var'=coxUnivTable(time,event,data.frame(x=gene.cut)))
  } else {
    ans <- coxUnivTable(time,event,data.frame(x=gene.cut))
  }
  ans
}

cumHazard <- function(event, time, gene, geneName='', cut, numgroups, groups, timelimit,
                   xlab='Time to event', ylab='Cumulative hazard', legendpos='bottomright',
                   legendcex=0.7, col, main='', lty=1, ...) {
  kaplan(event, time, gene, geneName, cut, numgroups, groups, timelimit, xlab, ylab, legendpos,
         legendcex, col, main, lty, fun='cumhaz')
}

cumIncidence <- function(event, time, gene, geneName='', cut, numgroups, groups, timelimit,
                   xlab='Time to event', ylab='Cumulative incidence', legendpos='bottomright',
                   legendcex=0.7, col, main='', lty=1, ...) {
  kaplan(event, time, gene, geneName, cut, numgroups, groups, timelimit, xlab, ylab, legendpos,
         legendcex, col, main, lty, fun='event', mark.time=F, ...)
}
