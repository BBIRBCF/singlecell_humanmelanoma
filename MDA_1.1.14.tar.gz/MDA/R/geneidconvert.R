############ entreztomouse4302 ############

setMethod("entreztomouse4302", signature(entrezid='list', mouse4302='missing'),
function(entrezid, mouse4302, homol, useSymbols=FALSE) {
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("entrezgene"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('entrez','mouse4302')
  }
  ans <- lapply(entrezid, function(z) entreztomouse4302(entrezid=z, homol=homol, useSymbols=useSymbols))
  return(ans)
}
)

setMethod("entreztomouse4302", signature(entrezid='missing', mouse4302='list'),
function(entrezid, mouse4302, homol, useSymbols=FALSE) {
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("entrezgene"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('entrez','mouse4302')
  }
  ans <- lapply(mouse4302, function(z) entreztomouse4302(mouse4302=z, homol=homol, useSymbols=useSymbols))
  return(ans)
}
)

setMethod("entreztomouse4302", signature(entrezid='character', mouse4302='missing'),
function(entrezid, mouse4302, homol, useSymbols=FALSE) {
  require(biomaRt)
  require(mouse4302.db)
  require(AnnotationDbi)
  require(org.Hs.eg.db)
  if (missing(homol)) {
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("entrezgene"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('entrez','mouse4302')
  }
  cat('Converting IDs...\n')
  homol <- homol[homol$entrez!='',]
  mouse4302 <- unique(homol[homol[,'entrez'] %in% entrezid,'mouse4302']) #map with biomaRt
  unmapped <- entrezid[!(entrezid %in% homol[,'entrez'])]
  unmapped.sym <- unique(as.character(AnnotationDbi::mget(unmapped,org.Hs.egSYMBOL,ifnotfound=NA)))
  myMap <- toTable(mouse4302SYMBOL)
  mouse4302.unm <- unique(myMap[toupper(myMap$symbol) %in% unmapped.sym,'probe_id']) #map the ones that could not be mapped with biomaRt via symbol
  mouse4302 <- unique(c(mouse4302,mouse4302.unm))
  return(mouse4302)
}
)

setMethod("entreztomouse4302", signature(entrezid='missing', mouse4302='character'),
function(entrezid, mouse4302, homol, useSymbols=FALSE) {
  require(biomaRt)
  require(mouse4302.db)
  require(AnnotationDbi)
  require(org.Hs.eg.db)
  if (missing(homol)) {
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("entrezgene"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('entrez','mouse4302')
  }
  cat('Converting IDs...\n')
  homol <- homol[homol$entrez!='',]
  entrezid <- unique(homol[homol[,'mouse4302'] %in% mouse4302,'entrez']) #map with biomaRt
  if (useSymbols) {
    unmapped <- mouse4302[!(mouse4302 %in% homol[,'mouse4302'])]
    unmapped.sym <- unique(as.character(AnnotationDbi::mget(unmapped,mouse4302SYMBOL,ifnotfound=NA)))
    unmapped.sym <- as.character(unmapped.sym[!is.na(unmapped.sym)])
    entrez.unm <- AnnotationDbi::mget(toupper(unmapped.sym),revmap(org.Hs.egSYMBOL),ifnotfound=NA) #map the ones that could not be mapped with biomaRt via symbol
    entrez.unm <- as.character(unlist(entrez.unm))
    entrez.unm <- entrez.unm[!is.na(entrez.unm)]
    entrezid <- unique(c(entrezid,entrez.unm))
  }
  return(entrezid)
}
)

############### hgu133plus2todrosophila2 ##############

setMethod("hgu133plus2todrosophila2", signature(hgu133plus2='missing', drosophila2='list'),
function(hgu133plus2, drosophila2, homol, returnTable=FALSE) {
  ans <- vector("list",length(drosophila2)); names(ans) <- names(drosophila2)
  for (i in 1:length(ans)) ans[[i]] <- hgu133plus2todrosophila2(drosophila2=drosophila2[[i]],homol=homol,returnTable=returnTable)
  return(ans)
}
)

setMethod("hgu133plus2todrosophila2", signature(hgu133plus2='missing', drosophila2='character'),
function(hgu133plus2, drosophila2, homol, returnTable=FALSE) {
  require(drosophila2.db)
  require(hgu133plus2.db)
  require(AnnotationDbi)
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    drosophila2Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("affy_hg_u133_plus_2"),mart=human,attributesL=c("affy_mouse430_2"),martL=drosophila2Mart)
    colnames(homol) <- c('hgu133plus2','drosophila2')
  }
  cat('Converting IDs...\n')
  homol <- homol[homol$hgu133plus2!='',]
  #
  hgu133plus2 <- homol[homol[,'drosophila2'] %in% drosophila2,] #map with biomaRt
  unmapped <- drosophila2[!(drosophila2 %in% homol[,'drosophila2'])]
  unmapped.sym <- data.frame(drosophila2=unmapped,symbol=as.character(AnnotationDbi::mget(unmapped,drosophila2SYMBOL,ifnotfound=NA)))
  unmapped.sym <- unique(unmapped.sym[!is.na(unmapped.sym$symbol),])
  unmapped.sym$symbol <- as.character(unmapped.sym$symbol)
  hgu133plus2.unm <- AnnotationDbi::mget(toupper(unmapped.sym$symbol),revmap(hgu133plus2SYMBOL),ifnotfound=NA) #map the ones that could not be mapped with biomaRt via symbol
  hgu133plus2.unm <- data.frame(drosophila2=rep(unmapped.sym$drosophila2,sapply(hgu133plus2.unm,length)),hgu133plus2=as.character(unlist(hgu133plus2.unm)))
  hgu133plus2.unm <- hgu133plus2.unm[!is.na(hgu133plus2.unm$hgu133plus2),]
  if (!returnTable) {
    hgu133plus2 <- unique(c(hgu133plus2[,'hgu133plus2'],hgu133plus2.unm[,'hgu133plus2']))
  } else {
    hgu133plus2 <- rbind(hgu133plus2,hgu133plus2.unm)
  }
  return(hgu133plus2)
}
)

############### hgu133plus2tomouse4302 ##############

setMethod("hgu133plus2tomouse4302", signature(hgu133plus2='list', mouse4302='missing'),
function(hgu133plus2, mouse4302, homol, returnTable=FALSE) {
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("affy_hg_u133_plus_2"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('hgu133plus2','mouse4302')
  }
  ans <- lapply(hgu133plus2, function(z) hgu133plus2tomouse4302(hgu133plus2=z, homol=homol, returnTable=returnTable))
  return(ans)
}
)

setMethod("hgu133plus2tomouse4302", signature(hgu133plus2='missing', mouse4302='list'),
function(hgu133plus2, mouse4302, homol, returnTable=FALSE) {
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("affy_hg_u133_plus_2"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('hgu133plus2','mouse4302')
  }
  ans <- lapply(mouse4302, function(z) hgu133plus2tomouse4302(mouse4302=z, homol=homol, returnTable=returnTable))
  return(ans)
}
)

setMethod("hgu133plus2tomouse4302", signature(hgu133plus2='missing', mouse4302='character'),
function(hgu133plus2, mouse4302, homol, returnTable=FALSE) {
  require(mouse4302.db)
  require(hgu133plus2.db)
  require(AnnotationDbi)
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("affy_hg_u133_plus_2"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('hgu133plus2','mouse4302')
  }
  cat('Converting IDs...\n')
  homol <- homol[homol$hgu133plus2!='',]
  #
  hgu133plus2 <- homol[homol[,'mouse4302'] %in% mouse4302,] #map with biomaRt
  unmapped <- mouse4302[!(mouse4302 %in% homol[,'mouse4302'])]
  unmapped.sym <- data.frame(mouse4302=unmapped,symbol=as.character(AnnotationDbi::mget(unmapped,mouse4302SYMBOL,ifnotfound=NA)))
  unmapped.sym <- unique(unmapped.sym[!is.na(unmapped.sym$symbol),])
  unmapped.sym$symbol <- as.character(unmapped.sym$symbol)
  hgu133plus2.unm <- AnnotationDbi::mget(toupper(unmapped.sym$symbol),revmap(hgu133plus2SYMBOL),ifnotfound=NA) #map the ones that could not be mapped with biomaRt via symbol
  hgu133plus2.unm <- data.frame(mouse4302=rep(unmapped.sym$mouse4302,sapply(hgu133plus2.unm,length)),hgu133plus2=as.character(unlist(hgu133plus2.unm)))
  hgu133plus2.unm <- hgu133plus2.unm[!is.na(hgu133plus2.unm$hgu133plus2),]
  if (!returnTable) {
    hgu133plus2 <- unique(c(hgu133plus2[,'hgu133plus2'],hgu133plus2.unm[,'hgu133plus2']))
  } else {
    hgu133plus2 <- rbind(hgu133plus2,hgu133plus2.unm)
  }
  return(hgu133plus2)
}
)

setMethod("hgu133plus2tomouse4302", signature(hgu133plus2='character', mouse4302='missing'),
function(hgu133plus2, mouse4302, homol, returnTable=FALSE) {
  require(mouse4302.db)
  require(hgu133plus2.db)
  require(AnnotationDbi)
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    human <- useMart("ensembl","hsapiens_gene_ensembl")
    mouse4302Mart <- useMart("ensembl","mmusculus_gene_ensembl")
    homol <- getLDS(attributes = c("affy_hg_u133_plus_2"),mart=human,attributesL=c("affy_mouse430_2"),martL=mouse4302Mart)
    colnames(homol) <- c('hgu133plus2','mouse4302')
  }
  cat('Converting IDs...\n')
  homol <- homol[homol$hgu133plus2!='',]
  #
  mouse4302 <- homol[homol[,'hgu133plus2'] %in% hgu133plus2,'mouse4302'] #map with biomaRt
  unmapped <- hgu133plus2[!(hgu133plus2 %in% homol[,'hgu133plus2'])]
  unmapped.sym <- unique(as.character(AnnotationDbi::mget(unmapped,hgu133plus2SYMBOL,ifnotfound=NA)))
  myMap <- toTable(mouse4302SYMBOL)
  mouse4302.unm <- unique(myMap[toupper(myMap$symbol) %in% unmapped.sym,'probe_id']) #map the ones that could not be mapped with biomaRt via symbol
  mouse4302 <- unique(c(mouse4302,mouse4302.unm))
  return(mouse4302)
}
)


################### hgu133plus2tohgu133a #####################

setMethod("hgu133plus2tohgu133a", signature(hgu133plus2='list', hgu133a='missing'),
function(hgu133plus2, hgu133a, simplify=TRUE) {
  ans <- lapply(hgu133plus2, function(z) hgu133plus2tohgu133a(hgu133plus2=z))
  return(ans)
}
)

setMethod("hgu133plus2tohgu133a", signature(hgu133plus2='missing', hgu133a='list'),
function(hgu133plus2, hgu133a, simplify=TRUE) {
  ans <- lapply(hgu133a, function(z) hgu133plus2tohgu133a(hgu133a=z))
  return(ans)
}
)

setMethod("hgu133plus2tohgu133a", signature(hgu133plus2='character', hgu133a='missing'),
function(hgu133plus2, hgu133a, simplify=TRUE) {
  require(hgu133plus2.db)
  require(hgu133a.db)
  entrezid <- unlist( AnnotationDbi::mget(hgu133plus2[!is.na(hgu133plus2)],hgu133plus2ENTREZID,ifnotfound=NA))
  n <- names(entrezid)[!is.na(entrezid)]
  hgu133a <-  AnnotationDbi::mget(entrezid[!is.na(entrezid)],revmap(hgu133aENTREZID),ifnotfound=NA)
  names(hgu133a) <- n
  ans <- hgu133a[!is.na(hgu133a)]
  if (simplify) ans <- unlist(ans)
  return(ans)
}
)

setMethod("hgu133plus2tohgu133a", signature(hgu133plus2='missing', hgu133a='character'),
function(hgu133plus2, hgu133a, simplify=TRUE) {
  entrezid <- unlist( AnnotationDbi::mget(hgu133a[!is.na(hgu133a)],hgu133aENTREZID,ifnotfound=NA))
  n <- names(entrezid)[!is.na(entrezid)]
  hgu133plus2 <-  AnnotationDbi::mget(entrezid[!is.na(entrezid)],revmap(hgu133plus2ENTREZID),ifnotfound=NA)
  names(hgu133plus2) <- n
  ans <- hgu133plus2[!is.na(hgu133plus2)]
  if (simplify) ans <- unlist(ans)
  return(ans)
}
)


################### entrezidtosymbol #####################

setMethod("entrezidtosymbol", signature(entrezid='character', organism='character'),
function(entrezid, organism='hsapiens', homol, returnTable=FALSE) {
  if (missing(homol)) {
    require(biomaRt)
    cat('Obtaining homology table from biomaRt...\n')
    mymart <- useMart("ensembl",paste(organism,'_gene_ensembl',sep=''))
    homol <- getLDS(attributes = c("entrezgene"),mart=mymart,attributesL=c("external_gene_id"),martL=mymart)
    colnames(homol) <- c('entrezid','symbol')
  }
  cat('Converting IDs...\n')
  homol <- homol[homol$entrezid!='' & !is.na(homol$entrezid),]
  homol$entrezid <- as.character(homol$entrezid)
  homol$symbol <- as.character(homol$symbol)  
  #
  homol <- homol[homol[,'entrezid'] %in% entrezid,]
  if (!returnTable) {
    symbol <- homol[match(entrezid,homol$entrezid),'symbol']
  } else {
    symbol <- homol[match(entrezid,homol$entrezid),]
  }
  return(symbol)
}
)
