density3D <- function(x, y, xlab='x', ylab='y', zlab='Density', zlim, theta=20, phi=20) {
  require(MASS)
  n <- 100
  set.seed(125)
  d <- kde2d(x,y,n=100)
  oldmar <- par()$mar
  par(mar=c(0.5,0.5,0.5,0.5))
  ncol <- 100
  z   <- d$z
  if (missing(zlim)) zlim <- c(0,max(z))
  nrz <- nrow(z)
  ncz <- ncol(z)
  couleurs  <- tail(topo.colors(trunc(1.4 * ncol)),ncol)
  fcol      <- couleurs[trunc(z/zlim[2]*(ncol-1))+1]
  fcol[z<5] <- 'cyan'
  fcol[z<0.1] <- 'white'
  dim(fcol) <- c(nrz,ncz)
  fcol      <- fcol[-nrz,-ncz]
  persp(d,col=fcol,theta=theta,phi=phi,xlab=xlab,ylab=ylab,zlab=zlab,zlim=zlim)
  par(mar=oldmar)
}
