getQuery4LOCALFILE <- function (ids) {
#Get directory for LOCAL FILE
    blanks <- ids == "&nbsp;"
    out <- paste("LOCALFILE_",ids,".html",sep = "")
    out <- sub(":","",out) #remove strange characters from file name
    out[blanks] <- "&nbsp;"
    return(out)
}
