zscoreAdjustment.ExpressionSet <- function(x,adjustmentVariable,center=TRUE,scale=TRUE) {
  if (!(adjustmentVariable %in% names(pData(x)))) { stop('Specified variable not found in pData') }
  myVar <- unique(pData(x)[,adjustmentVariable])
  exprsx <- exprs(x)
  for (i in 1:length(myVar)) {
    exprsx[,pData(x)[,adjustmentVariable]==myVar[i]] <- t(scale(t(exprsx[,pData(x)[,adjustmentVariable]==myVar[i]]),scale=scale,center=center))
  }
  exprs(x) <- exprsx
  return(x)
}

