setMethod("GeneSetMeans", signature(x='ExpressionSet', genesets='list'), 
function(x, genesets, center=FALSE, scale=FALSE,summary='mean') {
  if (ncol(x)==0) stop('ExpressionSet is empty')
  if (any(unlist(lapply(genesets,function(i) any(!(i %in% featureNames(x))))))) stop('Some identifiers in genesets do not exist in featureNames(x)')
  if (center) exprs(x) <- exprs(x)-rowMeans(exprs(x),na.rm=TRUE)
  if (scale) exprs(x) <- exprs(x) / rowSD(exprs(x),na.rm=TRUE)  
  if (summary=='mean') mysum <- colMeans else mysum <- function(z) apply(z,2,'median',na.rm=TRUE)
  ans <- do.call("rbind",lapply(genesets,function(y) mysum(exprs(x[y,,drop=F]))))
  rownames(ans) <- names(genesets)
  ans <- new("ExpressionSet",exprs=ans,phenoData=phenoData(x))
  return(ans)  
}
)

setMethod("GeneSetMeans", signature(x='matrix', genesets='list'), 
function(x, genesets, center=FALSE, scale=FALSE,summary='mean') {
  if (ncol(x)==0) stop('matrix is empty')
  if (any(unlist(lapply(genesets,function(i) any(!(i %in% rownames(x))))))) stop('Some identifiers in genesets do not exist in rownames(x)')
  if (center) x <- x - rowMeans(x, na.rm=TRUE)
  if (scale) x <- x / rowSD(x,na.rm=TRUE)
  if (summary=='mean') mysum <- colMeans else mysum <- function(z) apply(z,2,'median',na.rm=TRUE)
  ans <- do.call("rbind",lapply(genesets,function(y) mysum(x[y,,drop=F])))
  rownames(ans) <- names(genesets)
  return(ans)  
}
)

setMethod("GeneSetMeans", signature(x='data.frame', genesets='list'), 
function(x, genesets, center=FALSE, scale=FALSE,summary='mean') {
  if (ncol(x)==0) stop('data.frame is empty')
  if (any(unlist(lapply(genesets,function(i) any(!(i %in% rownames(x))))))) stop('Some identifiers in genesets do not exist in rownames(x)')
  if (center) x <- x - rowMeans(x, na.rm=TRUE)
  if (scale) x <- x / rowSD(x,na.rm=TRUE)  
  if (summary=='mean') mysum <- colMeans else mysum <- function(z) apply(z,2,'median',na.rm=TRUE)
  ans <- do.call("rbind",lapply(genesets,function(y) mysum(x[y,,drop=F])))
  rownames(ans) <- names(genesets)
  return(ans)  
}
)
