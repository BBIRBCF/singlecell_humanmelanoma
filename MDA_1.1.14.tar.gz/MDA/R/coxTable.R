coxUnivTable <- function(time,event,x,time2,showRaw=TRUE, signHr=TRUE) {
  #Report a table with univariate Cox model results for all columns in x
  #Note: p-value computed using likelihood-ratio test
  require(survival)
  if (!is.data.frame(x)) stop('x should be a data.frame')
  for (i in 1:ncol(x)) { if (is.character(x[,i])) x[,i] <- factor(x[,i]) }
  design <- lapply(x,function(z) makeDesign(data.frame(na.omit(z))))
  isfac <- sapply(x,is.factor) 
  if (any(isfac)) {
    nlev <- rep(0,length(design))
    nlev[isfac] <- sapply(design[isfac],ncol)+1
    nrow <- 2*sum(!isfac) + sum(ifelse(isfac & (nlev==2),1,0)) + sum(ifelse(isfac & (nlev>2),1+.5*nlev*(nlev-1),0))
  } else {
    nrow <- 2*ncol(x)
  }
  xout <- matrix(NA,nrow=nrow,ncol=4)
  colnames(xout) <- c('HR','CI.low','CI.up','Pvalue')
  rownames(xout) <- rep('',nrow(xout))
  rowid <- 1
  for (i in 1:ncol(x)) {
    sel <- !is.na(x[,i]) #; time <- time[sel]; if (!missing(time2)) time2 <- time2[sel]; event <- event[sel]; x <- x[sel,,drop=FALSE] #remove NAs
    if (missing(time2)) {
      s <- Surv(time[sel], event[sel])
    } else {
      s <- Surv(time[sel], time2[sel], event[sel])
    }
    if (!isfac[i]) {
      coxph1 <- coxph(s ~ design[[i]])
      xout[rowid,1:3] <- coxci(coxph1, signHr)[-4]
      coxph1 <- coxph(s ~ scale(design[[i]]))
      xout[rowid+1,1:3] <- coxci(coxph1, signHr)[-4]
      xout[rowid,4] <- xout[rowid+1,4] <- 1-pchisq(2*diff(summary(coxph1)$loglik),df=1)
      rownames(xout)[rowid:(rowid+1)] <- paste(names(x)[i],c('(raw)','(+1SD)'))
      rowid <- rowid+2
    } else {
      coxph1 <- coxph(s ~ design[[i]])
      xout[rowid,4] <- 1-pchisq(2*diff(summary(coxph1)$loglik),df=ncol(design[[i]]))
      if (length(levels(x[,i]))==2) {
        if (missing(time2)) {
          cf <- do.call(c,coxContrasts(time=time,event=event,x=x[,i],test='lr', signHr=signHr))
        } else {
          cf <- do.call(c,coxContrasts(time=time,time2=time2,event=event,x=x[,i],test='lr', signHr=signHr))
        }
        xout[rowid,] <- cf
        rownames(xout)[rowid] <- sub('^hr\\.x',paste(names(x)[i],'.',sep=''),names(cf)[1])
        rowid <- rowid+1
      } else {
        rownames(xout)[rowid] <- names(design)[i]
        rowid <- rowid+1
        if (missing(time2)) {
          cf <- do.call(cbind,coxContrasts(time=time,event=event,x=x[,i],test='lr', signHr=signHr))
        } else {
          cf <- do.call(cbind,coxContrasts(time=time,time2=time2,event=event,x=x[,i],test='lr', signHr=signHr))
        }
        xout[rowid:(rowid+nrow(cf)-1),] <- cf
        rownames(xout)[rowid:(rowid+nrow(cf)-1)] <- rownames(cf)
        rowid <- rowid+nrow(cf)
      }
    }
  }
  #round
  xout[,1:3] <- round(xout[,1:3],2)
  #Take care of Infinite HR
  inf <- which(abs(xout[,1])>10^5)
  xout[inf,1] <- Inf*sign(xout[inf,1])
  xout[inf,2] <- xout[inf,3] <- NA
  if (!showRaw) {
    xout <- xout[!grepl('\\(raw\\)',rownames(xout)),]
  }
  xout
}

coxci <- function(x, signHr=TRUE) {
  #Returns summary of Coxph model (estimates, CI, p-values)
  s <- summary(x)$coefficients
  s <- cbind(s[,'coef'], s[,'coef']-1.96*s[,'se(coef)'], s[,'coef']+1.96*s[,'se(coef)'])
  if (signHr) {
    s <- cbind(round(sign(s)*exp(abs(s)),2), round(summary(x)$coefficients[,'Pr(>|z|)'],4))
  } else {
    s <- cbind(round(exp(s),2), round(summary(x)$coefficients[,'Pr(>|z|)'],4))
  }
  colnames(s) <- c('HR','CI.low','CI.high','Pvalue')
  #s <- cbind(s[,1],paste('(',s[,2],'- ',s[,3],')',sep=''),s[,4])
  return(s)
}

makeDesign <- function(xadj) {
  #Auxiliary function to create design matrix for adjustment variables
  if (!is.data.frame(xadj)) stop('xadj must be of type data.frame')
  txt <- paste("designadj <- model.matrix(~",paste(paste('xadj[,',1:ncol(xadj),']',sep=''),collapse='+'),")",sep='')
  eval(parse(text=txt))
  designadj <- designadj[,-1,drop=FALSE]
  for (i in 1:ncol(xadj)) colnames(designadj) <- sub(paste('xadj\\[, ',i,'\\]',sep=''),names(xadj)[i],colnames(designadj))
  designadj
}

coxContrasts <- function(time, event, x, xadj, time2, test='lr', signHr=TRUE) {
  #Hazard Ratios and Likelihood Ratio Test p-values for all pairwise comparisons
  # Input
  # - time, event: time to event, and event indicator (event==TRUE indicates event, event==FALSE indicates censored obs)
  # - time, event: time to event, and event indicator (event==TRUE indicates event, event==FALSE indicates censored obs)
  # - time2: end time. Start time has to be specified too.
  # - x: covariate of interest (converted to a factor automatically)
  # - xadj: adjustment variables
  # - test: test to be used. Valid options are 'wald' for Wald test and 'lr' for Likelihood Ratio Test.
  # Output: list with 2 components
  #  - hr: hazard ratios resulting from all pairwise comparisons
  #  - pval: p-values resulting from all pairwise comparisons
  #Note: needs auxiliary function makeDesign
  if (!is.factor(x)) x <- factor(x)
  id <- diag(length(levels(x)))
  hr <- ci <- pval <- vector("list",ncol(id)-1)
  if (!missing(xadj)) {
    if (is.null(dim(xadj))) {
      sel <- !is.na(xadj) & !is.na(event); time <- time[sel]; if (!missing(time2)) time2 <- time2[sel]; event <- event[sel]; x <- x[sel]; xadj <- xadj[sel] #remove NAs
      designadj <- model.matrix(~ xadj)[,-1]
    } else {
      sel <- rowSums(is.na(xadj))==0 & !is.na(event); time <- time[sel]; if (!missing(time2)) time2 <- time2[sel]; event <- event[sel]; x <- x[sel]; xadj <- xadj[sel,,drop=FALSE] #remove NAs
      designadj <- makeDesign(xadj)
    }
  }
  for (i in 1:(ncol(id)-1)) {
    if (length(levels(x))>2) contrasts(x, how.many=length(levels(x))) <- id[,-i]
    colnames(contrasts(x)) <- paste(levels(x)[-i],rep(levels(x)[i],ncol(id)-1),sep='vs')
    if (missing(time2)) {
      s <- Surv(time, event)
    } else {
      s <- Surv(time, time2, event)
    }
    if (missing(xadj)) {
      coxph1 <- try(coxph(s ~ x), silent=TRUE)
    } else {
      coxph1 <- try(coxph(s ~ x + designadj), silent=TRUE)
    }
    if (signHr) {
      hr[[i]] <- round(exp(abs(coef(coxph1)))*sign(coef(coxph1)),2)[i:(ncol(id)-1)]
    } else {
      hr[[i]] <- round(exp(coef(coxph1)),2)[i:(ncol(id)-1)]
    }
    ci[[i]] <- summary(coxph1)$conf.int[i:(ncol(id)-1),3:4]
    if (signHr) {
      ci[[i]][ci[[i]]<1 & !is.na(ci[[i]])] <- -1/ci[[i]][ci[[i]]<1 & !is.na(ci[[i]])]
    }
    if (test=='lr') {
      pval[[i]] <- double(0)
      if (length(levels(x))>2) {
        for (j in i:(ncol(id)-1)) {
          x2 <- x; x2[x2==levels(x2)[j+1]] <- levels(x2)[i]; x2 <- factor(x2)
          if (missing(xadj)) {
            coxph2 <- try(coxph(s ~ x2), silent=TRUE)
          } else {
            coxph2 <- try(coxph(s ~ x2 + designadj), silent=TRUE)
          }
          pval[[i]] <- c(pval[[i]],1-pchisq(2*(coxph1$loglik[2] - coxph2$loglik[2]), df=anova(coxph1, coxph2)[[3]][2]))
        }
      } else {
        pval <- 1 - pchisq(2*diff(coxph1$loglik), df=1)
      }
    } else if (test=='wald') {
      pval[[i]] <- summary(coxph1)$coef[i:(ncol(id)-1),'Pr(>|z|)']
    } else {
      stop("Invalid test. Specify 'wald' or 'lr'")
    }
  }
  return(list(hr=unlist(hr),ci=do.call(rbind,ci),pval=unlist(pval)))
}

coxMultivTable <- function(time,event,x,digits=Inf,time2,showRaw=TRUE, signHr=TRUE) {
  #Report a table with multivariate Cox model including all columns in x
  #Note: p-values computed using likelihood-ratio test. Reported up to digits precision
  #Note: needs auxiliary function makeDesign
  require(survival)
  ans <- vector("list",ncol(x))
  for (i in 1:ncol(x)) { if (is.character(x[,i])) x[,i] <- factor(x[,i]) }
  sel <- rowSums(is.na(x))==0 & !is.na(event); time.f <- time[sel]; if (!missing(time2)) time2.f <- time2[sel]; event.f <- event[sel]; x <- x[sel,,drop=FALSE] #remove NAs
  for (i in 1:ncol(x)) {
    xin <- x[,i]; xadj <- x[,-i,drop=FALSE]
    if (is.factor(xin)) xin <- factor(xin)
    for (j in 1:ncol(xadj)) if (is.factor(xadj[,j])) xadj[,j] <- factor(xadj[,j])
    xadj <- xadj[,!(rapply(xadj,is.factor) & rapply(xadj,function(x) length(levels(x))==1)),drop=F]
    if (ncol(xadj)==0) {
      warning(paste('All adjustment variables were removed because they had no levels without missing. Univariate analysis has been done instead for variable: "',colnames(x)[i],'",\n',sep=''))
      if (missing(time2)) {
        tmp <- coxUnivTable(time.f,event.f,data.frame(aaaa=xin))
      } else {
        tmp <- coxUnivTable(time=time.f,time2=time2.f,event=event.f,x=data.frame(aaaa=xin))
      }
      rownames(tmp) <- gsub('aaaa',colnames(x)[i],rownames(tmp))
      ans[[i]] <- tmp
    } else {
      designadj <- makeDesign(xadj)
      #Overall p-value
      if (missing(time2)) {
        s <- Surv(time.f, event.f)
      } else {
        s <- Surv(time.f, time2.f, event.f)
      }
      coxph1 <- try(coxph(s ~ xin + designadj), silent=TRUE)
      coxph2 <- try(coxph(s ~ designadj), silent=TRUE)
      pval <- 1-pchisq(2*(coxph1$loglik[2] - coxph2$loglik[2]), df=anova(coxph1, coxph2)[[3]][2])
      if (is.numeric(xin)) {
        coxph0 <- try(coxph(s ~ scale(xin) + designadj), silent=TRUE) #Standardized coef
        ans[[i]] <- rbind(c(coxci(coxph1, signHr)[1,-4],pval),c(coxci(coxph0, signHr)[1,-4],pval))
        rownames(ans[[i]]) <- paste(names(x)[i],c('(raw)','(+1SD)'))
      } else {
      if (missing(time2)) {
        cf <- coxContrasts(time=time.f, event=event.f, x=xin, xadj=xadj, test='lr', signHr=signHr) #all pairwise comp
      } else {
        cf <- coxContrasts(time=time.f, time2=time2.f, event=event.f, x=xin, xadj=xadj, test='lr', signHr=signHr) #all pairwise comp
      }
        if (length(unique(xin))>2) {
          ans[[i]] <- rbind(c(NA,NA,NA,pval),do.call(cbind,cf))
          rownames(ans[[i]])[1] <- names(x)[i]
        } else {
          ans[[i]] <- matrix(c(unlist(cf)[-4],pval),nrow=1)
          rownames(ans[[i]]) <- paste(names(x)[i],'.',sub('x','',names(cf[[1]])),sep='')
        }
      }
      if (!is.infinite(digits)) ans[[i]][,4] <- round(ans[[i]][,4],digits=digits)
    }
  }
  ans <- do.call(rbind,ans); colnames(ans) <- c('HR','CI.low','CI.up','Pvalue')
  ans[,2] <- round(ans[,2],2); ans[,3] <- round(ans[,3],2)
  #Take care of Infinite HR
  inf <- which(abs(ans[,1])>10^5)
  ans[inf,1] <- Inf*sign(ans[inf,1])
  ans[inf,2] <- ans[inf,3] <- NA
  if (!showRaw) {
    ans <- ans[!grepl('\\(raw\\)',rownames(ans)),]
  }
  ans
}

