rowSD <- function(x,...) { return(sqrt(rowVar(x,...))) }
