list2html <- function(x,sel,otherinfo,orderby,decreasing=TRUE,fname,title='',digits=4,geneLimit=500,ifnotfound=NA,featureNames='probeids',...) {
require(annotate)
require("KEGG.db")
require(AnnotationDbi)
if (missing(fname)) stop('fname must be specified')
if (class(x)!='ExpressionSet') stop('x must be an object of class ExpressionSet')
if (!missing(orderby)) { if ((length(orderby)>1) | (!is.character(orderby))) stop('orderby must be a character vector of length 1') }

eval(parse(text=paste("require(",annotation(x),".db)",sep=''))) #load annotation package
envSYMBOL <- AnnotationDbi::get(paste(annotation(x),"SYMBOL", sep = ""))
envGENENAME <- AnnotationDbi::get(paste(annotation(x),"GENENAME", sep = ""))
envENTREZID <- AnnotationDbi::get(paste(annotation(x),"ENTREZID", sep = ""))
envGO <- AnnotationDbi::get(paste(annotation(x),"GO", sep = ""))
envPATH <- AnnotationDbi::get(paste(annotation(x),"PATH", sep = ""))

# Select genes
xsel <- x[sel,]
for (i in 1:length(otherinfo)) { otherinfo[[i]] <- otherinfo[[i]][sel] }

geneList <- list(); repository <- list(); head <- character()
if (featureNames=='probeids') {
  probeids <- featureNames(xsel)
  geneList$probeids <- probeids
  head <- c(head,'Probe ID')
  repository <- c(repository,"affy")
} else if (featureNames=='symbol') {
  probeids <- AnnotationDbi::mget(featureNames(xsel),revmap(envSYMBOL),ifnotfound=NA)
  probeids <- unlist(lapply(probeids,function(x) return(x[1])))
}

entrez <- unlist(AnnotationDbi::mget(probeids,envENTREZID,ifnotfound=ifnotfound))
geneList$entrez <- entrez
head <- c(head,'Entrez ID')
repository <- c(repository,"en")

go <- AnnotationDbi::mget(probeids,envGO,ifnotfound=ifnotfound)
go <- lapply(go,'names')
geneList$go <- go
head <- c(head,'GO')
repository <- c(repository,"go")


#Other annotation: columns without live links
existanno <- FALSE

symbol <- unlist(AnnotationDbi::mget(probeids,envSYMBOL,ifnotfound=ifnotfound))
if (!existanno) { otheranno <- list(symbol=symbol); existanno <- TRUE } else otheranno$symbol <- symbol
head <- c(head,'Symbol')

gname <- unlist(AnnotationDbi::mget(probeids,envGENENAME,ifnotfound=ifnotfound))
if (!existanno) { otheranno <- list(gname=gname); existanno <- TRUE } else otheranno$gname <- gname
head <- c(head,'Gene Name')

gpath <- AnnotationDbi::mget(probeids,envPATH,ifnotfound=ifnotfound)
gpath[is.na(gpath)] <- "-1"
gpath <- lapply(gpath,AnnotationDbi::mget,envir=KEGGPATHID2NAME,ifnotfound=NA)
if (!existanno) { otheranno <- list(gpath=gpath); existanno <- TRUE } else otheranno$gpath <- gpath
head <- c(head,'KEGG pathway')

if (!missing(orderby)) {
  o <- order(otherinfo[[orderby]],decreasing=decreasing)
  for (i in 1:length(geneList)) { geneList[[i]] <- geneList[[i]][o] }
  for (i in 1:length(otheranno)) { otheranno[[i]] <- otheranno[[i]][o] }
  for (i in 1:length(otherinfo)) { otherinfo[[i]] <- otherinfo[[i]][o] }
}

head <- c(head,names(otherinfo))
otherinfo <- c(otheranno,otherinfo)

if (length(geneList[[1]])>geneLimit) {
  for (i in 1:length(geneList)) geneList[[i]] <- geneList[[i]][1:geneLimit]
  for (i in 1:length(otherinfo)) otherinfo[[i]] <- otherinfo[[i]][1:geneLimit]
}

htmlpage(genelist=geneList,filename=fname,title=title,othernames=otherinfo,table.head=head,repository=repository,digits=digits,...)
sortDragHtmlTable(filename=fname)
}
