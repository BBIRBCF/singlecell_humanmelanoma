annotateFeatures <- function(features,  annotation) {
  eval(parse(text=paste('require(', annotation, '.db)', sep='')))
  if (grepl('org.*.eg',  annotation,  perl=T)) {
    entrezid <- features
  } else {
    probeids <- features
    envirEntrez <- eval(parse(text=paste(annotation, 'ENTREZID', sep='')))
    entrezid <- unlist(AnnotationDbi::mget(features, envirEntrez, ifnotfound=NA))
  }
  envirSymbol <- eval(parse(text=paste(annotation, 'SYMBOL', sep='')))
  envirGenena <- eval(parse(text=paste(annotation, 'GENENAME', sep='')))    
  symbol <- unlist(AnnotationDbi::mget(features, envirSymbol, ifnotfound=NA))
  genename <- unlist(AnnotationDbi::mget(features, envirGenena, ifnotfound=NA))
  if (grepl('org.*.eg',  annotation,  perl=T)) {
    ans <- data.frame(entrezid=entrezid, symbol=symbol, genename=genename)
  } else {
    ans <- data.frame(probeids=probeids, entrezid=entrezid, symbol=symbol, genename=genename)
  }
  return(ans)
}

setGeneric("getAnnotations",function (x, features, annotation) standardGeneric("getAnnotations"))

setMethod("getAnnotations",signature(x='missing', features='character', annotation='character'),
  function (features, annotation) {
    ans <- annotateFeatures(features, annotation)
    ans
  }
)

setMethod("getAnnotations",signature(x='ExpressionSet', features='missing', annotation='missing'),
  function (x) {
    features <- featureNames(x)
    annotation <- annotation(x)
    ans <- annotateFeatures(features, annotation)
    ans
  }
)
