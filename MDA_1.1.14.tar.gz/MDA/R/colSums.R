colSums <- function (x, ...) { if (is.vector(x)) { x } else { base::colSums(x, ...) } }
