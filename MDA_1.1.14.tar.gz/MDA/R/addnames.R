addnames <- function(x,y,mynames,col,...) {
# Adds names to an existing plot, making sure that the labels don't overlap
# Arguments: coordinates x,y, text labels in mynames, label colors in col, further arguments to text in ...
  xy <- data.frame(x=x,y=y,col=col)
  xy <- aggregate.data.frame(xy,by=list(mynames),'mean')
  xy <- xy[order(xy$x,xy$y),]
  overlap <- c(FALSE,(abs(xy$x[-nrow(xy)]-xy$x[-1])/diff(range(xy$x)) + abs(xy$y[-nrow(xy)]-xy$y[-1])/diff(range(xy$y)))<.05)
  xy$x[overlap] <- xy$x[overlap] + .05*diff(range(xy$x))
  text(xy$x,xy$y,xy[,1],col=xy$col,...)
}
