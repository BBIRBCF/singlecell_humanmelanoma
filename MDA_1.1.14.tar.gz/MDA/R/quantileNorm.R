quantileNorm <- function(x) { require(Biobase); UseMethod("quantileNorm") }
