plottopgenes <- function(x,groups,orderby,decreasing=TRUE,genesel=1:10,file,xjust=0,yjust=1,xlab='Expression level',yaxt='n',xlim,ylim=c(0,1),...) {
# Plots expression values for top 10 genes (can specify number other than 10 as well)
# - x: data with expression values (genes in rows and samples in columns)
# - groups: vector of length equal to ncol(x) indicating to which group does each sample belong
# - orderby: numeric vector used to order the genes. Must be of length equal to nrow(x)
# - decreasing: should order be decreasing?
# - genesel: sequence with number of genes to plot. Specifying >>10 may produce plots that are hard to read.
# - file: if specified, the plot is saved as a pdf file
# - xjust, yjust: specifies corner in which legend should appear
# - ...: further arguments passed to plot

if (length(groups)!=ncol(x)) stop('length(groups) must be equal to ncol(x)')
if (length(orderby)!=nrow(x)) stop('length(orderby) must be equal to nrow(x)')
if (!missing(file)) pdf(file)

if (is(x, "exprSet") | is(x, "ExpressionSet")) {
  if (is.character(groups) && length(groups) == 1) { groups <- as.factor(pData(x)[, groups]) }
  x <- exprs(x)
}

ngene <- length(genesel)
o <- order(orderby,decreasing=decreasing)
x <- x[o,]
if (missing(xlim)) {
  if (min(x[genesel,])>0) xlim <- c(min(x[genesel,])/1.2,max(x[genesel,])*1.2) else xlim <- c(1.2*min(x[genesel,]),max(x[genesel,])*1.2)
}
plot(as.numeric(x[genesel[1],]),rep(1,ncol(x)),col=as.numeric(factor(groups)),pch=as.numeric(factor(groups)),xlab=xlab,ylim=c(0,1),yaxt='n',ylab='',xlim=xlim,...)
for (i in 2:ngene) { points(as.numeric(x[genesel[i],]),rep(1-(i-1)/ngene,ncol(x)),col=as.numeric(factor(groups)),pch=as.numeric(factor(groups))) }
xpos <- ifelse(xjust==0,xlim[1],xlim[2]); ypos <- ifelse(yjust==0,0,1)
legend(xpos,ypos,names(table(groups)),xjust=xjust,yjust=yjust,pch=1:length(table(groups)),col=1:length(table(groups)))

if (!missing(file)) dev.off()
}
